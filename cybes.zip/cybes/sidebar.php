<?php
/*
 * Main widget area Sitebar
 */
if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>
<div class="webtheme-widget-sitebar">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</div>
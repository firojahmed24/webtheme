<?php
	function webtheme_metabox() {
		$prefix = '_webtheme_';
		//header metabox
	 	$page_heading_style = new_cmb2_box( array(
		'id'            => $prefix . 'header_style_option',
		'title'         => esc_html__( 'Header Style Option', 'webtheme' ),
		'object_types'  => array( 'page','post' ), // Post type
		'priority'   => 'high',
		) );
		$page_heading_style->add_field( array(
			'name'    => esc_html__('Top Menu Style ','webtheme'),
			'id'      => $prefix . 'webtheme_header_top_menu',
			'type'    => 'radio_inline',
			'options' => array(
			'1' => esc_html__( 'Show Top Menu in this page', 'webtheme' ),
			'2'   => esc_html__( 'Hide Top Menu in this page', 'webtheme' ),
			),
			'default' =>'1',
		) );
		
		$page_heading_style->add_field( array(
			'name' => 'Add menu elements',
			'id' => $prefix . 'menu_elements',
			'type' => 'multicheck_inline',
			'select_all_button' => false,
			'options' => array(
				'check1' => 'Search Icon',
				'check2' => 'Button',
			)
		) );

		$page_heading_style->add_field( array(
			'name' => 'Transparent Menu',
			'desc' => 'Active',
			'id'   => 'transparent_menu',
			'type' => 'checkbox',
		) );
		$page_heading_style->add_field( array(
			'name' => 'Full Width Header',
			'desc' => 'Active',
			'id'   => 'full_header',
			'type' => 'checkbox',
		) );

		//breadcrumb metabox
		$page_breadcrumb = new_cmb2_box( array(
		   'id'            => $prefix . 'pageid1',
		   'title'         => esc_html__( 'Breadcumb Option', 'webtheme' ),
		   'object_types'  => array( 'post','page','case_study_post','portfolio_post_type' ), // Post type
		   'priority'   => 'high',
		) );
		
		$page_breadcrumb->add_field( array(
			'name'    => esc_html__('Breadcrumb','webtheme'),
			'id'      => $prefix . 'breadcrumbs',
			'type'    => 'radio_inline',
			'options' => array(
			'0' => esc_html__( 'Show breadcrumb', 'webtheme' ),
			'1'   => esc_html__( 'Hide breadcrumb', 'webtheme' ),
			),
			'default' =>0,
		) );
		$page_breadcrumb->add_field( array(
			'name'    => esc_html__('Breadcrumb Title','webtheme'),
			'id'      => $prefix . 'breadcrumb_title',
			'type'    => 'radio_inline',
			'options' => array(
				'show_title' => esc_html__( 'Show Title', 'webtheme' ),
				'hide_title'   => esc_html__( 'Hide Title', 'webtheme' ),
			),
			'default' =>'show_title',
		) );    
		$page_breadcrumb->add_field(array(
			'name' => esc_html__( 'Background Image', 'webtheme' ),
			'id'   => $prefix .'bg_image',
			'desc' => esc_html__( 'insert image here', 'webtheme' ),  
			'type' => 'file',
		) );  

		$page_breadcrumb->add_field( array(
			'name'             => esc_html__('Text Transform','webtheme'),
			'desc'             => esc_html__('Select an option','webtheme'),
			'id'   => $prefix .'page_text_transform',
			'type'             => 'select',
			'show_option_none' => true,
			'options'          => array(
				'lowercase' => esc_html__( 'Transform lowercase', 'webtheme' ),
				'uppercase'   => esc_html__( 'Transform uppercase', 'webtheme' ),
				'capitalize'     => esc_html__( 'Transform capitalize', 'webtheme' ),
			),
		) );	

		//Case Study
		$casestudy = new_cmb2_box( array(
			'id'            => $prefix . 'casestudy_post',
			'title'         => esc_html__( 'Case Study Option', 'webtheme' ),
			'object_types'  => array( 'case_study_post' ), // Post type
			'priority'   => 'high',
		) );
			$casestudy->add_field( array(
				'name'       => esc_html__( 'Case Study Description', 'webtheme' ),
				'desc'       => esc_html__( 'Description', 'webtheme' ),
				'id'         => 'webtheme_casestudy_description',
				'type'       => 'wysiwyg',
			) );	

			//===================================
			//Portfolio Metaboxes
			//===================================  

			$portfolio = new_cmb2_box( array(
				'id'            => $prefix . 'portfolio_post',
				'title'         => esc_html__( 'Portfolio Option', 'webtheme' ),
				'object_types'  => array( 'portfolio_post_type', ), // Post type
				'priority'   => 'high',
			) );
			$portfolio->add_field( array(
				'name'       => esc_html__( 'Portfolio Work Information', 'webtheme' ),
				'desc'       => esc_html__( 'Portfolio Work Details information.', 'webtheme' ),
				'id'         => 'webtheme_portfolio_description',
				'type'       => 'wysiwyg',
			) );				
			
			 // $portfolio->add_field( array(
			 //  'name'    => esc_html__('Show/Hide Title','webtheme'),			  
			 //  'id'      => $prefix . 'pshow_title',
			 //  'type'    => 'radio_inline',
			 //  'options' => array(
				// 'ptitle_show' => esc_html__( 'Show', 'webtheme' ),
				// 'ptitle_hide'   => esc_html__( 'Hide', 'webtheme' ),
			 //  ),
			 //  'default' =>'ptitle_show',
			 // ) );					
			 // $portfolio->add_field( array(
			 //  'name'    => esc_html__('Show/Hide Category','webtheme'),			  
			 //  'id'      => $prefix . 'pshow_cat',
			 //  'type'    => 'radio_inline',
			 //  'options' => array(
				// 'pcat_show' => esc_html__( 'Show', 'webtheme' ),
				// 'pcat_hide'   => esc_html__( 'Hide', 'webtheme' ),
			 //  ),
			 //  'default' =>'pcat_show',
			 // ) );
			   
		
		//post tab metabox
			$emtab = new_cmb2_box( array(
				'id'            => $prefix . 'em_tab',
				'title'         => esc_html__( 'Tab Option', 'webtheme' ),
				'object_types'  => array( 'em_tab' ), // Post type
				'priority'   => 'high',
			) );

				$emtab->add_field( array(
					'name'       => esc_html__( 'Tab Menu Name', 'webtheme' ),
					'desc'       => esc_html__( 'insert tab menu here', 'webtheme' ),
					'id'         => $prefix . 'em_tab_menu',
					'type'       => 'text',
				) );					
									
				$emtab->add_field(array(
					'name' => esc_html__( 'Tab Menu Image', 'webtheme' ),
					'id'   => $prefix .'em_tab_image',
					'desc'       => esc_html__( 'insert image here', 'webtheme' ),  
					'type' => 'file',
				) );
				$emtab->add_field( array(
					'name'       => esc_html__( 'Tab Menu Active', 'webtheme' ),
					'desc'       => esc_html__( 'must be set "active in" class into one post from all post, for active tab item', 'webtheme' ),
					'id'         => $prefix . 'em_tab_active',
					'type'       => 'text',
				) );
				$emtab->add_field( array(
					'name'       => esc_html__( 'Tab Icon Name', 'webtheme' ),
					'desc'       => esc_html__( 'Type Your favorite Font awesome Icon name', 'webtheme' ),
					'id'         => $prefix . 'em_tab_icon',
					'type'       => 'text',
				) );
							
			//slider table metabox
				$slider = new_cmb2_box( array(
					'id'            => $prefix . 'webtheme_slider',
					'title'         => esc_html__( 'Slider Option', 'webtheme' ),
					'object_types'  => array( 'em_slider', ), // Post type
					'priority'   => 'high',
				) );
	
	
			$slider->add_field( array(
				'name'       => esc_html__( 'Title', 'webtheme' ),
				'desc'       => esc_html__( 'insert title here. for highlight text use <span> ex-<span>Design</span>', 'webtheme' ),
				'id'         => $prefix . 'em_slide_title',
				'type'       => 'textarea_small',
			) );

			$slider->add_field( array(
				'name'    => esc_html__('Title Animate','webtheme'),
				'id'      => $prefix . 'em_aimate_title',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'bounceIn' => esc_html__( 'bounceIn', 'webtheme' ),				
					'bounceInDown' => esc_html__( 'bounceInDown', 'webtheme' ),				
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'webtheme' ),				
					'bounceInRight' => esc_html__( 'bounceInRight', 'webtheme' ),				
					'bounceInUp' => esc_html__( 'bounceInUp', 'webtheme' ),				
					'fadeIn' => esc_html__( 'fadeIn', 'webtheme' ),				
					'fadeInDown' => esc_html__( 'fadeInDown', 'webtheme' ),				
					'fadeInDownBig' => esc_html__( 'fadeInDownBig', 'webtheme' ),				
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'webtheme' ),				
					'fadeInLeftBig' => esc_html__( 'fadeInLeftBig', 'webtheme' ),				
					'fadeInRight' => esc_html__( 'fadeInRight', 'webtheme' ),				
					'fadeInRightBig' => esc_html__( 'fadeInRightBig', 'webtheme' ),				
					'fadeInUp' => esc_html__( 'fadeInUp', 'webtheme' ),				
					'fadeInUpBig' => esc_html__( 'fadeInUpBig', 'webtheme' ),				
					'rotateIn' => esc_html__( 'rotateIn', 'webtheme' ),				
					'rotateInDownLeft' => esc_html__( 'rotateInDownLeft', 'webtheme' ),				
					'rotateInDownRight' => esc_html__( 'rotateInDownRight', 'webtheme' ),				
					'rotateInUpLeft' => esc_html__( 'rotateInUpLeft', 'webtheme' ),				
					'rotateInUpRight' => esc_html__( 'rotateInUpRight', 'webtheme' ),				
					'rollIn' => esc_html__( 'rollIn', 'webtheme' ),				
					'zoomIn' => esc_html__( 'zoomIn', 'webtheme' ),				
					'zoomInDown' => esc_html__( 'zoomInDown', 'webtheme' ),				
					'zoomInLeft' => esc_html__( 'zoomInLeft', 'webtheme' ),				
					'zoomInRight' => esc_html__( 'zoomInRight', 'webtheme' ),				
					'zoomInUp' => esc_html__( 'zoomInUp', 'webtheme' ),				
					'slideInDown' => esc_html__( 'slideInDown', 'webtheme' ),				
					'slideInLeft' => esc_html__( 'slideInLeft', 'webtheme' ),				
					'slideInRight' => esc_html__( 'slideInRight', 'webtheme' ),				
					'slideInUp' => esc_html__( 'slideInUp', 'webtheme' ),				
				),
				'default' =>'slideInRight',
			) );
			
			$slider->add_field( array(
				'name'    => esc_html__('Title Animate Duration','webtheme'),
				'id'      => $prefix . 'em_durations_title',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0.1' => esc_html__( 'point 1s', 'webtheme' ),							
					'0.2' => esc_html__( 'point 2s', 'webtheme' ),							
					'0.3' => esc_html__( 'point 3s', 'webtheme' ),							
					'0.4' => esc_html__( 'point 4s', 'webtheme' ),							
					'0.5' => esc_html__( 'point 5s', 'webtheme' ),							
					'0.6' => esc_html__( 'point 6s', 'webtheme' ),							
					'0.7' => esc_html__( 'point 7s', 'webtheme' ),							
					'0.8' => esc_html__( 'point 8s', 'webtheme' ),							
					'0.9' => esc_html__( 'point 9s', 'webtheme' ),							
					'1.2' => esc_html__( '1 point 2s', 'webtheme' ),							
					'1.3' => esc_html__( '1 point 3s', 'webtheme' ),							
					'1.4' => esc_html__( '1 point 4s', 'webtheme' ),							
					'1.5' => esc_html__( '1 point 5s', 'webtheme' ),							
					'1.8' => esc_html__( '1 point 8s', 'webtheme' ),							
					'2' => esc_html__( '2s', 'webtheme' ),							
					'2.2' => esc_html__( '2 point 2s', 'webtheme' ),							
					'2.3' => esc_html__( '2 point 5s', 'webtheme' ),							
					'3' => esc_html__( '3s', 'webtheme' ),							
				),
				'default' =>'2',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Title Animate Delay','webtheme'),
				'id'      => $prefix . 'em_dealy_title',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0' => esc_html__( 'point 0s', 'webtheme' ),							
					'0.1' => esc_html__( 'point 1s', 'webtheme' ),							
					'0.2' => esc_html__( 'point 2s', 'webtheme' ),							
					'0.3' => esc_html__( 'point 3s', 'webtheme' ),							
					'0.4' => esc_html__( 'point 4s', 'webtheme' ),							
					'0.5' => esc_html__( 'point 5s', 'webtheme' ),							
					'0.6' => esc_html__( 'point 6s', 'webtheme' ),							
					'0.7' => esc_html__( 'point 7s', 'webtheme' ),							
					'0.8' => esc_html__( 'point 8s', 'webtheme' ),							
					'0.9' => esc_html__( 'point 9s', 'webtheme' ),							
					'1.2' => esc_html__( '1 point 2s', 'webtheme' ),							
					'1.3' => esc_html__( '1 point 3s', 'webtheme' ),							
					'1.4' => esc_html__( '1 point 4s', 'webtheme' ),							
					'1.5' => esc_html__( '1 point 5s', 'webtheme' ),							
					'1.8' => esc_html__( '1 point 8s', 'webtheme' ),							
					'2' => esc_html__( '2s', 'webtheme' ),							
					'2.2' => esc_html__( '2 point 2s', 'webtheme' ),							
					'2.3' => esc_html__( '2 point 5s', 'webtheme' ),							
					'3' => esc_html__( '3s', 'webtheme' ),							
				),
				'default' =>'0',
			) );		

			$slider->add_field( array(
				'name'       => esc_html__( 'Sub Title', 'webtheme' ),
				'desc'       => esc_html__( 'insert sub-title here. for highlight text use <span> ex-<span>website</span>', 'webtheme' ),
				'id'         => $prefix . 'em_slide_subtitle',
				'type'       => 'textarea_small',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Sub Title Animate','webtheme'),
				'id'      => $prefix . 'em_aimate_subtitle',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'bounceIn' => esc_html__( 'bounceIn', 'webtheme' ),				
					'bounceInDown' => esc_html__( 'bounceInDown', 'webtheme' ),				
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'webtheme' ),				
					'bounceInRight' => esc_html__( 'bounceInRight', 'webtheme' ),				
					'bounceInUp' => esc_html__( 'bounceInUp', 'webtheme' ),				
					'fadeIn' => esc_html__( 'fadeIn', 'webtheme' ),				
					'fadeInDown' => esc_html__( 'fadeInDown', 'webtheme' ),				
					'fadeInDownBig' => esc_html__( 'fadeInDownBig', 'webtheme' ),				
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'webtheme' ),				
					'fadeInLeftBig' => esc_html__( 'fadeInLeftBig', 'webtheme' ),				
					'fadeInRight' => esc_html__( 'fadeInRight', 'webtheme' ),				
					'fadeInRightBig' => esc_html__( 'fadeInRightBig', 'webtheme' ),				
					'fadeInUp' => esc_html__( 'fadeInUp', 'webtheme' ),				
					'fadeInUpBig' => esc_html__( 'fadeInUpBig', 'webtheme' ),				
					'rotateIn' => esc_html__( 'rotateIn', 'webtheme' ),				
					'rotateInDownLeft' => esc_html__( 'rotateInDownLeft', 'webtheme' ),				
					'rotateInDownRight' => esc_html__( 'rotateInDownRight', 'webtheme' ),				
					'rotateInUpLeft' => esc_html__( 'rotateInUpLeft', 'webtheme' ),				
					'rotateInUpRight' => esc_html__( 'rotateInUpRight', 'webtheme' ),				
					'rollIn' => esc_html__( 'rollIn', 'webtheme' ),				
					'zoomIn' => esc_html__( 'zoomIn', 'webtheme' ),				
					'zoomInDown' => esc_html__( 'zoomInDown', 'webtheme' ),				
					'zoomInLeft' => esc_html__( 'zoomInLeft', 'webtheme' ),				
					'zoomInRight' => esc_html__( 'zoomInRight', 'webtheme' ),				
					'zoomInUp' => esc_html__( 'zoomInUp', 'webtheme' ),				
					'slideInDown' => esc_html__( 'slideInDown', 'webtheme' ),				
					'slideInLeft' => esc_html__( 'slideInLeft', 'webtheme' ),				
					'slideInRight' => esc_html__( 'slideInRight', 'webtheme' ),				
					'slideInUp' => esc_html__( 'slideInUp', 'webtheme' ),				
				),
				'default' =>'slideInRight',
			) );
			
			$slider->add_field( array(
				'name'    => esc_html__('Sub Title Animate Duration','webtheme'),
				'id'      => $prefix . 'em_durations_subtitle',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0.1' => esc_html__( 'point 1s', 'webtheme' ),							
					'0.2' => esc_html__( 'point 2s', 'webtheme' ),							
					'0.3' => esc_html__( 'point 3s', 'webtheme' ),							
					'0.4' => esc_html__( 'point 4s', 'webtheme' ),							
					'0.5' => esc_html__( 'point 5s', 'webtheme' ),							
					'0.6' => esc_html__( 'point 6s', 'webtheme' ),							
					'0.7' => esc_html__( 'point 7s', 'webtheme' ),							
					'0.8' => esc_html__( 'point 8s', 'webtheme' ),							
					'0.9' => esc_html__( 'point 9s', 'webtheme' ),							
					'1.2' => esc_html__( '1 point 2s', 'webtheme' ),							
					'1.3' => esc_html__( '1 point 3s', 'webtheme' ),							
					'1.4' => esc_html__( '1 point 4s', 'webtheme' ),							
					'1.5' => esc_html__( '1 point 5s', 'webtheme' ),							
					'1.8' => esc_html__( '1 point 8s', 'webtheme' ),							
					'2' => esc_html__( '2s', 'webtheme' ),							
					'2.2' => esc_html__( '2 point 2s', 'webtheme' ),							
					'2.3' => esc_html__( '2 point 5s', 'webtheme' ),							
					'3' => esc_html__( '3s', 'webtheme' ),							
				),
				'default' =>'2',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Sub Title Animate Delay','webtheme'),
				'id'      => $prefix . 'em_dealy_subtitle',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0' => esc_html__( 'point 0s', 'webtheme' ),							
					'0.1' => esc_html__( 'point 1s', 'webtheme' ),							
					'0.2' => esc_html__( 'point 2s', 'webtheme' ),							
					'0.3' => esc_html__( 'point 3s', 'webtheme' ),							
					'0.4' => esc_html__( 'point 4s', 'webtheme' ),							
					'0.5' => esc_html__( 'point 5s', 'webtheme' ),							
					'0.6' => esc_html__( 'point 6s', 'webtheme' ),							
					'0.7' => esc_html__( 'point 7s', 'webtheme' ),							
					'0.8' => esc_html__( 'point 8s', 'webtheme' ),							
					'0.9' => esc_html__( 'point 9s', 'webtheme' ),							
					'1.2' => esc_html__( '1 point 2s', 'webtheme' ),							
					'1.3' => esc_html__( '1 point 3s', 'webtheme' ),							
					'1.4' => esc_html__( '1 point 4s', 'webtheme' ),							
					'1.5' => esc_html__( '1 point 5s', 'webtheme' ),							
					'1.8' => esc_html__( '1 point 8s', 'webtheme' ),							
					'2' => esc_html__( '2s', 'webtheme' ),							
					'2.2' => esc_html__( '2 point 2s', 'webtheme' ),							
					'2.3' => esc_html__( '2 point 5s', 'webtheme' ),							
					'3' => esc_html__( '3s', 'webtheme' ),							
				),
				'default' =>'0',
			) );				
			$slider->add_field( array(
				'name'       => esc_html__( 'Content', 'webtheme' ),
				'desc'       => esc_html__( 'insert content here', 'webtheme' ),
				'id'         => $prefix . 'em_slide_textarea',
				'type'       => 'textarea',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Content Animate','webtheme'),
				'id'      => $prefix . 'em_aimate_content',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'bounceIn' => esc_html__( 'bounceIn', 'webtheme' ),				
					'bounceInDown' => esc_html__( 'bounceInDown', 'webtheme' ),				
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'webtheme' ),				
					'bounceInRight' => esc_html__( 'bounceInRight', 'webtheme' ),				
					'bounceInUp' => esc_html__( 'bounceInUp', 'webtheme' ),				
					'fadeIn' => esc_html__( 'fadeIn', 'webtheme' ),				
					'fadeInDown' => esc_html__( 'fadeInDown', 'webtheme' ),				
					'fadeInDownBig' => esc_html__( 'fadeInDownBig', 'webtheme' ),				
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'webtheme' ),				
					'fadeInLeftBig' => esc_html__( 'fadeInLeftBig', 'webtheme' ),				
					'fadeInRight' => esc_html__( 'fadeInRight', 'webtheme' ),				
					'fadeInRightBig' => esc_html__( 'fadeInRightBig', 'webtheme' ),				
					'fadeInUp' => esc_html__( 'fadeInUp', 'webtheme' ),				
					'fadeInUpBig' => esc_html__( 'fadeInUpBig', 'webtheme' ),				
					'rotateIn' => esc_html__( 'rotateIn', 'webtheme' ),				
					'rotateInDownLeft' => esc_html__( 'rotateInDownLeft', 'webtheme' ),				
					'rotateInDownRight' => esc_html__( 'rotateInDownRight', 'webtheme' ),				
					'rotateInUpLeft' => esc_html__( 'rotateInUpLeft', 'webtheme' ),				
					'rotateInUpRight' => esc_html__( 'rotateInUpRight', 'webtheme' ),				
					'rollIn' => esc_html__( 'rollIn', 'webtheme' ),				
					'zoomIn' => esc_html__( 'zoomIn', 'webtheme' ),				
					'zoomInDown' => esc_html__( 'zoomInDown', 'webtheme' ),				
					'zoomInLeft' => esc_html__( 'zoomInLeft', 'webtheme' ),				
					'zoomInRight' => esc_html__( 'zoomInRight', 'webtheme' ),				
					'zoomInUp' => esc_html__( 'zoomInUp', 'webtheme' ),				
					'slideInDown' => esc_html__( 'slideInDown', 'webtheme' ),				
					'slideInLeft' => esc_html__( 'slideInLeft', 'webtheme' ),				
					'slideInRight' => esc_html__( 'slideInRight', 'webtheme' ),				
					'slideInUp' => esc_html__( 'slideInUp', 'webtheme' ),				
				),
				'default' =>'slideInRight',
			) );
			
			$slider->add_field( array(
				'name'    => esc_html__('Content Animate Duration','webtheme'),
				'id'      => $prefix . 'em_durations_content',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0.1' => esc_html__( 'point 1s', 'webtheme' ),							
					'0.2' => esc_html__( 'point 2s', 'webtheme' ),							
					'0.3' => esc_html__( 'point 3s', 'webtheme' ),							
					'0.4' => esc_html__( 'point 4s', 'webtheme' ),							
					'0.5' => esc_html__( 'point 5s', 'webtheme' ),							
					'0.6' => esc_html__( 'point 6s', 'webtheme' ),							
					'0.7' => esc_html__( 'point 7s', 'webtheme' ),							
					'0.8' => esc_html__( 'point 8s', 'webtheme' ),							
					'0.9' => esc_html__( 'point 9s', 'webtheme' ),							
					'1.2' => esc_html__( '1 point 2s', 'webtheme' ),							
					'1.3' => esc_html__( '1 point 3s', 'webtheme' ),							
					'1.4' => esc_html__( '1 point 4s', 'webtheme' ),							
					'1.5' => esc_html__( '1 point 5s', 'webtheme' ),							
					'1.8' => esc_html__( '1 point 8s', 'webtheme' ),							
					'2' => esc_html__( '2s', 'webtheme' ),							
					'2.2' => esc_html__( '2 point 2s', 'webtheme' ),							
					'2.3' => esc_html__( '2 point 5s', 'webtheme' ),							
					'3' => esc_html__( '3s', 'webtheme' ),							
				),
				'default' =>'3',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Content Animate Delay','webtheme'),
				'id'      => $prefix . 'em_dealy_content',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0' => esc_html__( 'point 0s', 'webtheme' ),							
					'0.1' => esc_html__( 'point 1s', 'webtheme' ),							
					'0.2' => esc_html__( 'point 2s', 'webtheme' ),							
					'0.3' => esc_html__( 'point 3s', 'webtheme' ),							
					'0.4' => esc_html__( 'point 4s', 'webtheme' ),							
					'0.5' => esc_html__( 'point 5s', 'webtheme' ),							
					'0.6' => esc_html__( 'point 6s', 'webtheme' ),							
					'0.7' => esc_html__( 'point 7s', 'webtheme' ),							
					'0.8' => esc_html__( 'point 8s', 'webtheme' ),							
					'0.9' => esc_html__( 'point 9s', 'webtheme' ),							
					'1.2' => esc_html__( '1 point 2s', 'webtheme' ),							
					'1.3' => esc_html__( '1 point 3s', 'webtheme' ),							
					'1.4' => esc_html__( '1 point 4s', 'webtheme' ),							
					'1.5' => esc_html__( '1 point 5s', 'webtheme' ),							
					'1.8' => esc_html__( '1 point 8s', 'webtheme' ),							
					'2' => esc_html__( '2s', 'webtheme' ),							
					'2.2' => esc_html__( '2 point 2s', 'webtheme' ),							
					'2.3' => esc_html__( '2 point 5s', 'webtheme' ),							
					'3' => esc_html__( '3s', 'webtheme' ),							
				),
				'default' =>'0',
			) );				
			
			$slider->add_field( array(
				'name'       => esc_html__( 'Button Text 1', 'webtheme' ),
				'desc'       => esc_html__( 'insert button text here', 'webtheme' ),
				'id'         => $prefix . 'em_slide_btn1',
				'type'       => 'text',
			) );
			$slider->add_field( array(
				'name'       => esc_html__( 'Slide Image', 'webtheme' ),
				'desc'       => esc_html__( 'insert single slide image here', 'webtheme' ),
				'id'         => $prefix . 'em_slide_img',
				'type'       => 'file',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Image Animate','webtheme'),
				'id'      => $prefix . 'em_aimate_image',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'bounceIn' => esc_html__( 'bounceIn', 'webtheme' ),				
					'bounceInDown' => esc_html__( 'bounceInDown', 'webtheme' ),				
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'webtheme' ),				
					'bounceInRight' => esc_html__( 'bounceInRight', 'webtheme' ),				
					'bounceInUp' => esc_html__( 'bounceInUp', 'webtheme' ),				
					'fadeIn' => esc_html__( 'fadeIn', 'webtheme' ),				
					'fadeInDown' => esc_html__( 'fadeInDown', 'webtheme' ),				
					'fadeInDownBig' => esc_html__( 'fadeInDownBig', 'webtheme' ),				
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'webtheme' ),				
					'fadeInLeftBig' => esc_html__( 'fadeInLeftBig', 'webtheme' ),				
					'fadeInRight' => esc_html__( 'fadeInRight', 'webtheme' ),				
					'fadeInRightBig' => esc_html__( 'fadeInRightBig', 'webtheme' ),				
					'fadeInUp' => esc_html__( 'fadeInUp', 'webtheme' ),				
					'fadeInUpBig' => esc_html__( 'fadeInUpBig', 'webtheme' ),				
					'rotateIn' => esc_html__( 'rotateIn', 'webtheme' ),				
					'rotateInDownLeft' => esc_html__( 'rotateInDownLeft', 'webtheme' ),				
					'rotateInDownRight' => esc_html__( 'rotateInDownRight', 'webtheme' ),				
					'rotateInUpLeft' => esc_html__( 'rotateInUpLeft', 'webtheme' ),				
					'rotateInUpRight' => esc_html__( 'rotateInUpRight', 'webtheme' ),				
					'rollIn' => esc_html__( 'rollIn', 'webtheme' ),				
					'zoomIn' => esc_html__( 'zoomIn', 'webtheme' ),				
					'zoomInDown' => esc_html__( 'zoomInDown', 'webtheme' ),				
					'zoomInLeft' => esc_html__( 'zoomInLeft', 'webtheme' ),				
					'zoomInRight' => esc_html__( 'zoomInRight', 'webtheme' ),				
					'zoomInUp' => esc_html__( 'zoomInUp', 'webtheme' ),				
					'slideInDown' => esc_html__( 'slideInDown', 'webtheme' ),				
					'slideInLeft' => esc_html__( 'slideInLeft', 'webtheme' ),				
					'slideInRight' => esc_html__( 'slideInRight', 'webtheme' ),				
					'slideInUp' => esc_html__( 'slideInUp', 'webtheme' ),				
				),
				'default' =>'slideInRight',
			) );
			
			$slider->add_field( array(
				'name'    => esc_html__('Image Animate Duration','webtheme'),
				'id'      => $prefix . 'em_durations_image',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0.1' => esc_html__( 'point 1s', 'webtheme' ),							
					'0.2' => esc_html__( 'point 2s', 'webtheme' ),							
					'0.3' => esc_html__( 'point 3s', 'webtheme' ),							
					'0.4' => esc_html__( 'point 4s', 'webtheme' ),							
					'0.5' => esc_html__( 'point 5s', 'webtheme' ),							
					'0.6' => esc_html__( 'point 6s', 'webtheme' ),							
					'0.7' => esc_html__( 'point 7s', 'webtheme' ),							
					'0.8' => esc_html__( 'point 8s', 'webtheme' ),							
					'0.9' => esc_html__( 'point 9s', 'webtheme' ),							
					'1.2' => esc_html__( '1 point 2s', 'webtheme' ),							
					'1.3' => esc_html__( '1 point 3s', 'webtheme' ),							
					'1.4' => esc_html__( '1 point 4s', 'webtheme' ),							
					'1.5' => esc_html__( '1 point 5s', 'webtheme' ),							
					'1.8' => esc_html__( '1 point 8s', 'webtheme' ),							
					'2' => esc_html__( '2s', 'webtheme' ),							
					'2.2' => esc_html__( '2 point 2s', 'webtheme' ),							
					'2.3' => esc_html__( '2 point 5s', 'webtheme' ),							
					'3' => esc_html__( '3s', 'webtheme' ),							
				),
				'default' =>'2',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Image Animate Delay','webtheme'),
				'id'      => $prefix . 'em_dealy_image',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0' => esc_html__( 'point 0s', 'webtheme' ),							
					'0.1' => esc_html__( 'point 1s', 'webtheme' ),							
					'0.2' => esc_html__( 'point 2s', 'webtheme' ),							
					'0.3' => esc_html__( 'point 3s', 'webtheme' ),							
					'0.4' => esc_html__( 'point 4s', 'webtheme' ),							
					'0.5' => esc_html__( 'point 5s', 'webtheme' ),							
					'0.6' => esc_html__( 'point 6s', 'webtheme' ),							
					'0.7' => esc_html__( 'point 7s', 'webtheme' ),							
					'0.8' => esc_html__( 'point 8s', 'webtheme' ),							
					'0.9' => esc_html__( 'point 9s', 'webtheme' ),							
					'1.2' => esc_html__( '1 point 2s', 'webtheme' ),							
					'1.3' => esc_html__( '1 point 3s', 'webtheme' ),							
					'1.4' => esc_html__( '1 point 4s', 'webtheme' ),							
					'1.5' => esc_html__( '1 point 5s', 'webtheme' ),							
					'1.8' => esc_html__( '1 point 8s', 'webtheme' ),							
					'2' => esc_html__( '2s', 'webtheme' ),							
					'2.2' => esc_html__( '2 point 2s', 'webtheme' ),							
					'2.3' => esc_html__( '2 point 5s', 'webtheme' ),							
					'3' => esc_html__( '3s', 'webtheme' ),							
				),
				'default' =>'0',
			) );		

			$slider->add_field( array(
				'name'       => esc_html__( 'Button url 1', 'webtheme' ),
				'desc'       => esc_html__( 'insert button text url here', 'webtheme' ),
				'id'         => $prefix . 'em_slide_btn1utl',
				'type'       => 'text_url',
			) );			
			$slider->add_field( array(
				'name'       => esc_html__( 'Button Text 2', 'webtheme' ),
				'desc'       => esc_html__( 'insert button text here', 'webtheme' ),
				'id'         => $prefix . 'em_slide_btn2',
				'type'       => 'text',
			) );
			$slider->add_field( array(
				'name'       => esc_html__( 'Button url 2', 'webtheme' ),
				'desc'       => esc_html__( 'insert button text url here', 'webtheme' ),
				'id'         => $prefix . 'em_slide_btn2url',
				'type'       => 'text_url',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Button Animate','webtheme'),
				'id'      => $prefix . 'em_aimate_btn',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'bounceIn' => esc_html__( 'bounceIn', 'webtheme' ),				
					'bounceInDown' => esc_html__( 'bounceInDown', 'webtheme' ),				
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'webtheme' ),				
					'bounceInRight' => esc_html__( 'bounceInRight', 'webtheme' ),				
					'bounceInUp' => esc_html__( 'bounceInUp', 'webtheme' ),				
					'fadeIn' => esc_html__( 'fadeIn', 'webtheme' ),				
					'fadeInDown' => esc_html__( 'fadeInDown', 'webtheme' ),				
					'fadeInDownBig' => esc_html__( 'fadeInDownBig', 'webtheme' ),				
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'webtheme' ),				
					'fadeInLeftBig' => esc_html__( 'fadeInLeftBig', 'webtheme' ),				
					'fadeInRight' => esc_html__( 'fadeInRight', 'webtheme' ),				
					'fadeInRightBig' => esc_html__( 'fadeInRightBig', 'webtheme' ),				
					'fadeInUp' => esc_html__( 'fadeInUp', 'webtheme' ),				
					'fadeInUpBig' => esc_html__( 'fadeInUpBig', 'webtheme' ),				
					'rotateIn' => esc_html__( 'rotateIn', 'webtheme' ),				
					'rotateInDownLeft' => esc_html__( 'rotateInDownLeft', 'webtheme' ),				
					'rotateInDownRight' => esc_html__( 'rotateInDownRight', 'webtheme' ),				
					'rotateInUpLeft' => esc_html__( 'rotateInUpLeft', 'webtheme' ),				
					'rotateInUpRight' => esc_html__( 'rotateInUpRight', 'webtheme' ),				
					'rollIn' => esc_html__( 'rollIn', 'webtheme' ),				
					'zoomIn' => esc_html__( 'zoomIn', 'webtheme' ),				
					'zoomInDown' => esc_html__( 'zoomInDown', 'webtheme' ),				
					'zoomInLeft' => esc_html__( 'zoomInLeft', 'webtheme' ),				
					'zoomInRight' => esc_html__( 'zoomInRight', 'webtheme' ),				
					'zoomInUp' => esc_html__( 'zoomInUp', 'webtheme' ),				
					'slideInDown' => esc_html__( 'slideInDown', 'webtheme' ),				
					'slideInLeft' => esc_html__( 'slideInLeft', 'webtheme' ),				
					'slideInRight' => esc_html__( 'slideInRight', 'webtheme' ),				
					'slideInUp' => esc_html__( 'slideInUp', 'webtheme' ),				
				),
				'default' =>'bounceInUp',
			) );
			

			$slider->add_field( array(
				'name'    => esc_html__('Button Animate Duration','webtheme'),
				'id'      => $prefix . 'em_durations_btn',
				'show_option_none' => false,					
				'type'    => 'select',
				'options' => array(
					'0.1' => esc_html__( 'point 1s', 'webtheme' ),							
					'0.2' => esc_html__( 'point 2s', 'webtheme' ),							
					'0.3' => esc_html__( 'point 3s', 'webtheme' ),							
					'0.4' => esc_html__( 'point 4s', 'webtheme' ),							
					'0.5' => esc_html__( 'point 5s', 'webtheme' ),							
					'0.6' => esc_html__( 'point 6s', 'webtheme' ),							
					'0.7' => esc_html__( 'point 7s', 'webtheme' ),							
					'0.8' => esc_html__( 'point 8s', 'webtheme' ),							
					'0.9' => esc_html__( 'point 9s', 'webtheme' ),							
					'1.2' => esc_html__( '1 point 2s', 'webtheme' ),							
					'1.3' => esc_html__( '1 point 3s', 'webtheme' ),							
					'1.4' => esc_html__( '1 point 4s', 'webtheme' ),							
					'1.5' => esc_html__( '1 point 5s', 'webtheme' ),							
					'1.8' => esc_html__( '1 point 8s', 'webtheme' ),							
					'2' => esc_html__( '2s', 'webtheme' ),							
					'2.2' => esc_html__( '2 point 2s', 'webtheme' ),							
					'2.3' => esc_html__( '2 point 5s', 'webtheme' ),							
					'3' => esc_html__( '3s', 'webtheme' ),							
				),
				'default' =>'3',
			) );
			$slider->add_field( array(
				'name'    => esc_html__('Button Animate Delay','webtheme'),
				'id'      => $prefix . 'em_dealy_btn',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'0' => esc_html__( 'point 0s', 'webtheme' ),							
					'0.1' => esc_html__( 'point 1s', 'webtheme' ),							
					'0.2' => esc_html__( 'point 2s', 'webtheme' ),							
					'0.3' => esc_html__( 'point 3s', 'webtheme' ),							
					'0.4' => esc_html__( 'point 4s', 'webtheme' ),							
					'0.5' => esc_html__( 'point 5s', 'webtheme' ),							
					'0.6' => esc_html__( 'point 6s', 'webtheme' ),							
					'0.7' => esc_html__( 'point 7s', 'webtheme' ),							
					'0.8' => esc_html__( 'point 8s', 'webtheme' ),							
					'0.9' => esc_html__( 'point 9s', 'webtheme' ),							
					'1.2' => esc_html__( '1 point 2s', 'webtheme' ),							
					'1.3' => esc_html__( '1 point 3s', 'webtheme' ),							
					'1.4' => esc_html__( '1 point 4s', 'webtheme' ),							
					'1.5' => esc_html__( '1 point 5s', 'webtheme' ),							
					'1.8' => esc_html__( '1 point 8s', 'webtheme' ),							
					'2' => esc_html__( '2s', 'webtheme' ),							
					'2.2' => esc_html__( '2 point 2s', 'webtheme' ),							
					'2.3' => esc_html__( '2 point 5s', 'webtheme' ),							
					'3' => esc_html__( '3s', 'webtheme' ),							
				),
				'default' =>'1',
			) );				
			$slider->add_field( array(
				'name'    => esc_html__('Text Alignment Style','webtheme'),
				'id'      => $prefix . 'em_slider_posi',
				'show_option_none' => true,					
				'type'    => 'select',
				'options' => array(
					'' => esc_html__( 'Select alignment', 'webtheme' ),
					'text-left' => esc_html__( 'Left Alignment', 'webtheme' ),
					'text-center' => esc_html__( 'Center Alignment', 'webtheme' ),
					'text-right' => esc_html__( 'Right Alignment', 'webtheme' ),
				),
				'default' =>'text-center',
			) );				
			$slider->add_field( array(
				'name'       => esc_html__( 'More Sliders Option, Please see slider widget area', 'webtheme' ),
				'id'         => $prefix . 'title_heading_line',
				'type'       => 'title',
			) );
	}
	add_action( 'cmb2_admin_init', 'webtheme_metabox' );
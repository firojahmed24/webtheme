<?php
/**
 * ReduxFramework Barebones Sample Config File
 * For full documentation, please visit: http://devs.redux.io/
 * @package Redux Framework
 */
if ( ! class_exists( 'Redux' ) ) {
	return null;
}
/* Redux start here  */
$opt_name = 'cybes_opt';

    /* =====================================
    *       Header option link here 
    //======================================*/
    require_once (get_template_directory(). '/inc/header-option.php');

    /* =====================================
    *       Breadcumb option Link here
    ======================================*/
    require_once (get_template_directory(). '/inc/breadcumb-option.php');

	/* =====================================
    *    Theme Typography Start here
    //======================================*/
    require_once (get_template_directory(). '/inc/theme-typography-option.php');

$theme = wp_get_theme(); /* For use with some settings. Not necessary.*/

$args = array(
	/* REQUIRED!!  Change these values as you need otherwise do not change any text.*/
	'opt_name'                  => $opt_name,
	'display_name'              => $theme->get( 'Name' ),
	'display_version'           => $theme->get( 'Version' ),
	'menu_type'                 => 'menu',
	'allow_sub_menu'            => true,
	'menu_title'                => esc_html__( 'WebTheme Options', 'webtheme' ),
	'page_title'                => esc_html__( 'WebTheme Options', 'webtheme' ),
	'disable_google_fonts_link' => false,
	'admin_bar'                 => true,
	'admin_bar_icon'            => 'dashicons-portfolio',
	'admin_bar_priority'        => 50,
	'global_variable'           => '',
	'dev_mode'                  => true,
	'customizer'                => true,
	'page_priority'             => 20,
	'page_parent'               => 'themes.php',
	'page_permissions'          => 'manage_options',
	'menu_icon'                 => '',
	'last_tab'                  => '',
	'page_icon'                 => 'icon-themes',
	'page_slug'                 => '_options',
	'save_defaults'             => true,
	'default_show'              => false,
	'default_mark'              => '',
	'show_import_export'        => true,
	'transient_time'            => 60 * MINUTE_IN_SECONDS,
	'output'                    => true,
	'output_tag'                => true,
	'database'                  => '',
	'use_cdn'                   => true,
	'compiler'                  => true,
	'flyout_submenus'           => true,
	'font_display'              => 'swap',

	// HINTS.
	'hints'                     => array(
		'icon'          => 'el el-question-sign',
		'icon_position' => 'right',
		'icon_color'    => 'lightgray',
		'icon_size'     => 'normal',
		'tip_style'     => array(
			'color'   => 'light',
			'shadow'  => true,
			'rounded' => false,
			'style'   => '',
		),
		'tip_position'  => array(
			'my' => 'top left',
			'at' => 'bottom right',
		),
		'tip_effect'    => array(
			'show' => array(
				'effect'   => 'slide',
				'duration' => '500',
				'event'    => 'mouseover',
			),
			'hide' => array(
				'effect'   => 'slide',
				'duration' => '500',
				'event'    => 'click mouseleave',
			),
		),
	),
);

/* ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.*/
$args['admin_bar_links'][] = array(
	'id'    => 'redux-docs',
	'href'  => '//devs.redux.io/',
	'title' => esc_html__( 'Documentation', 'webtheme' ),
);

$args['admin_bar_links'][] = array(
	'id'    => 'redux-support',
	'href'  => '//github.com/ReduxFramework/redux-framework/issues',
	'title' => esc_html__( 'Support', 'webtheme' ),
);

$args['admin_bar_links'][] = array(
	'id'    => 'redux-extensions',
	'href'  => 'redux.io/extensions',
	'title' => esc_html__( 'Extensions', 'webtheme' ),
);

// SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
$args['share_icons'][] = array(
	'url'   => '//github.com/ReduxFramework/ReduxFramework',
	'title' => 'Visit us on GitHub',
	'icon'  => 'el el-github',
);
$args['share_icons'][] = array(
	'url'   => '//www.facebook.com/pages/Redux-Framework/243141545850368',
	'title' => esc_html__( 'Like us on Facebook', 'webtheme' ),
	'icon'  => 'el el-facebook',
);
$args['share_icons'][] = array(
	'url'   => '//youtube.com/reduxframework',
	'title' => esc_html__( 'Follow us on Youtube', 'webtheme' ),
	'icon'  => 'el el-youtube',
);
$args['share_icons'][] = array(
	'url'   => '//www.linkedin.com/company/redux-framework',
	'title' => esc_html__( 'FInd us on LinkedIn', 'webtheme' ),
	'icon'  => 'el el-linkedin',
);

// Panel Intro text -> before the form.
if ( ! isset( $args['global_variable'] ) || false !== $args['global_variable'] ) {
	if ( ! empty( $args['global_variable'] ) ) {
		$v = $args['global_variable'];
	} else {
		$v = str_replace( '-', '_', $args['opt_name'] );
	}
	$args['intro_text'] = '<p>' . sprintf( __( 'Did you know that Redux sets a global variable for you? To access any of your saved options from within your code you can use your global variable: $s', 'webtheme' ) . '</p>', '<strong>' . $v . '</strong>' );
} else {
	$args['intro_text'] = '<p>' . esc_html__( 'This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.', 'webtheme' ) . '</p>';
}

// Add content after the form.
$args['footer_text'] = '<p>' . esc_html__( 'This text is displayed below the options panel. It isn\'t required, but more info is always better! The footer_text field accepts all HTML.', 'webtheme' ) . '</p>';

Redux::set_args( $opt_name, $args );

/*
 * ---> END ARGUMENTS
 */

/*
 * ---> BEGIN HELP TABS
 */

$help_tabs = array(
	array(
		'id'      => 'redux-help-tab-1',
		'title'   => esc_html__( 'Theme Information 1', 'webtheme' ),
		'content' => '<p>' . esc_html__( 'This is the tab content, HTML is allowed.', 'webtheme' ) . '</p>',
	),

	array(
		'id'      => 'redux-help-tab-2',
		'title'   => esc_html__( 'Theme Information 2', 'webtheme' ),
		'content' => '<p>' . esc_html__( 'This is the tab content, HTML is allowed.', 'webtheme' ) . '</p>',
	),
);

Redux::set_help_tab( $opt_name, $help_tabs );

// Set the help sidebar.
$content = '<p>' . esc_html__( 'This is the sidebar content, HTML is allowed.', 'webtheme' ) . '</p>';
Redux::set_help_sidebar( $opt_name, $content );

/*
 * <--- END HELP TABS
 */

/* -> START Blog Details page */

$section = array(
	'title'  => esc_html__( 'Blog Details', 'webtheme' ),
	'id'     => 'blog_details',
	'desc'  => __( 'Here Enter Blog Details css', 'webtheme' ),
	'icon'   => 'el el-asterisk',
	'fields' => array(
		// blog details bg color
		array(
			'id'       => 'blog_details_background',
			'type'     => 'background',
			'title'    => __('Blog Details Background', 'webtheme'),
			'default'	=> array(
				'background' => '',
			),
			'output'    => array('.blog-details-section'),
		),
		// blog details author info typography
		array(
			'id'          => 'blog_details_category_typography',
			'type'        => 'typography', 
			'title'       => __('Author Category Typography', 'webtheme'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.blog-details-section .blog-post-category ul.post-categories li a'),
			'units'       =>'px',
			'subtitle'    => __('Blog Details category css typography.', 'webtheme'),
			'default'     => array(
				'color'       => '', 
				'font-style'  => '', 
				'font-family' => '', 
				'font-size'   => '', 
			),
		),
		array(
			'id'          => 'blog_details_autho_typography',
			'type'        => 'typography', 
			'title'       => __('Author info Typography', 'webtheme'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.blog-details-section .blog-author-img a'),
			'units'       =>'px',
			'subtitle'    => __('Blog Details author text typography.', 'webtheme'),
			'default'     => array(
				'color'       => '', 
				'font-style'  => '', 
				'font-family' => '', 
				'font-size'   => '', 
			),
		),
		array(
			'id'          => 'blog_details_date_typography',
			'type'        => 'typography', 
			'title'       => __('Author Date Typography', 'webtheme'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.blog-details-section .blog-post-time span'),
			'units'       =>'px',
			'subtitle'    => __('Blog Details Date CSS Typography.', 'webtheme'),
			'default'     => array(
				'color'       => '', 
				'font-style'  => '', 
				'font-family' => '', 
				'font-size'   => '', 
			),
		),

		array(
			'id'          => 'blog_details_title_typography',
			'type'        => 'typography', 
			'title'       => __('Blog Details Title Typography', 'webtheme'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.blog-details-section .blog-post-title h1 a '),
			'units'       =>'px',
			'subtitle'    => __('Blog Details Title css Typography', 'webtheme'),
			'default'     => array(
				'color'       => '', 
				'font-style'  => '', 
				'font-family' => '', 
				'font-size'   => '', 
			),
		),
		array(
			'id'          => 'description',
			'type'        => 'typography', 
			'title'       => __('Blog Details Description Typography', 'webtheme'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.blog-details-section .blog-post-description p '),
			'units'       =>'px',
			'subtitle'    => __('Blog Details Description css Typography', 'webtheme'),
			'default'     => array(
				'color'       => '', 
				'font-style'  => '', 
				'font-family' => '', 
				'font-size'   => '', 
			),
		),
		
	),
);

Redux::set_section( $opt_name, $section );

/* <- END Blog Details Page */

/* -> START Sidebar */

$section = array(
	'title'  => esc_html__( 'Sidebar', 'webtheme' ),
	'id'     => 'sidebar',
	'icon'   => 'el el-asterisk',
	'fields' => array(
		array(
			'id'          => 'sidebar_title_typography',
			'type'        => 'typography', 
			'title'       => __('Title Typography', 'webtheme'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.webtheme-widget-sitebar .widget h2'),
			'units'       =>'px',
			'subtitle'    => __('Typography option.', 'webtheme'),
			'default'     => array(
				'color'       => '', 
				'font-style'  => '', 
				'font-family' => '', 
				'google'      => true,
				'font-size'   => '', 
				'line-height' => ''
			),
		),
	),
);

Redux::set_section( $opt_name, $section );

/* <- END Sidebar */

/*========================
webtheme 404 FIELD
=========================*/	 
Redux::setSection( $opt_name, array(
	'title'     => esc_html__('404 Error Section', 'webtheme'),
   'id'         => 'webtheme_error_page',  
   'desc'       => esc_html__('You can change 404 background color or image.     ', 'webtheme'),
   'icon'       => 'el-icon-picture',
   'fields'    => array(
		   array(
			   'id'        => 'webtheme_background_404',
			   'type'      => 'background',
			   'output'    => array('.error-section'),
			   'title'     => esc_html__('404 Page Background Color', 'webtheme'),
			   'subtitle'  => esc_html__('404 background with image or color.', 'webtheme'),
			   'default'  => array(
				   'background-color' => '',
			   )
		   ),
		   array(								
			   'id'        => 'webtheme_not_title',
			   'type'      => 'color',
			   'title'     => esc_html__('Error Main Title Color', 'webtheme'),
			   'default'  => '',
			   'output'    => array(
			   'color' => '.error-main-title h3'
			   )
		   ),	
		   array(								
			   'id'        => 'webtheme_error_oops_title',
			   'type'      => 'color',
			   'title'     => esc_html__('Oops Title Color', 'webtheme'),
			   'default'  => '',
			   'output'    => array(
			   'color' => '.error-title-content .error-oops-title h3'
			   )
		   ),
		   array(								
			   'id'        => 'webtheme_error-please_title',
			   'type'      => 'color',
			   'title'     => esc_html__('Please Title Color', 'webtheme'),
			   'default'  => '',
			   'output'    => array(
			   'color' => '.error-please-title h2'
			   )
		   ),
		   array(								
			   'id'        => 'webtheme_error-page_description',
			   'type'      => 'color',
			   'title'     => esc_html__('Error Description Color', 'webtheme'),
			   'default'  => '',
			   'output'    => array(
			   'color' => '.error-page-description p'
			   )
		   ),					
		   array(
			   'id'        => 'error_information',
			   'type'      => 'editor',
			   'title'     => esc_html__('404 Information', 'webtheme'),
			   'subtitle'  => esc_html__('HTML tags allowed: a, br, em, strong', 'webtheme'),
			   'default'   => esc_html__('We are very sorry to say that our page is not found! ', 'webtheme'),
		   ), 
		   array(
			   'id'             => 'webtheme_notfound_spacing',
			   'type'           => 'spacing',
			   'output'         => array('.error-section'),
			   'mode'           => 'padding',
			   'units'          => array('em', 'px'),
			   'units_extended' => 'false',
			   'title'          => esc_html__('Error Section Padding Option', 'webtheme'),
			   'subtitle'       => esc_html__('Choose the spacing or padding', 'webtheme'),
			   'desc'           => esc_html__('You can enable or disable. Top, Bottom, Left, Right or Units.', 'webtheme'),
			   'default'            => array(
				   'padding-top'     => '', 
				   'padding-right'   => '', 
				   'padding-bottom'  => '', 
				   'padding-left'    => '',
				   'units'          => 'px', 
			   )
		   ),

		   
	   ),
) );
/* <- END 404 Page */



/* -> START Footer Section. */

$section = array(
	'title'  => esc_html__( 'Basic Field', 'webtheme' ),
	'id'     => 'footer',
	'desc'   => esc_html__( 'Basic field with no subsections.', 'webtheme' ),
	'icon'   => 'el el-asterisk',
	'fields' => array(
		array(
			'id'       => 'footer_widget_toggle',
			'type'     => 'switch',
			'title'    => esc_html__( 'Widget Area Show/Hide', 'webtheme' ),
			'subtitle' => esc_html__('If you ON this section, it will show footer widgets all your single page.', 'webtheme'),
			'default'  => true,
		),
		array(
			'id'        => 'footer_bg',
			'type'      => 'background',
			'title'     => esc_html__('Footer Background', 'webtheme'),
			'default'  => '',
			'output'    => array('.site-footer'),
			'default'  => array(
				'background-color' => '',
			)					
		),
	),
);

Redux::set_section( $opt_name, $section );

$section = array(
	'title' => __( 'Footer', 'webtheme' ),
	'id'    => 'footer',
	'icon'  => 'el el-asterisk',
);

Redux::set_section( $opt_name, $section );

$section = array(
	'title'      => esc_html__( 'Widget Area', 'webtheme' ),
	'id'         => 'opt-widget-subsection',
	'subsection' => true,
	'icon'   => 'el el-share-alt',
	'fields'     => array(
		array(
			'id'        => 'widget_column_count',
			'type'      => 'select',
			'title'     => esc_html__('Widget Column Count', 'webtheme'),
			'customizer_only'   => false,
			'options'   => array(
				'1' => esc_html__('Column 1','webtheme'),
				'2' => esc_html__('Column 2','webtheme'),
				'3' => esc_html__('Column 3','webtheme'),
				'4' => esc_html__('Column 4','webtheme'),
				'6' => esc_html__('Column 6','webtheme'),
			),
			'default'   =>'4'
		),
		array(	
			'id'        => 'widget_title_color',
			'type'      => 'color',
			'title'     => esc_html__('Widget Title Color', 'webtheme'),
			'default'  => '',
			'output'    => array(
				'color' => '.site-footer .footer-widget .widget-title'
			)
		),
		array(								
			'id'        => 'widget_text_color',
			'type'      => 'color',
			'title'     => esc_html__('Widget Text Color', 'webtheme'),
			'default'  => '',
			'output'    => array(
				'color' => '.site-footer .footer-widget .widget ul li a,
				.site-footer .footer-widget .widget p,
				.site-footer .footer-widget .widget .recent-post-item .recent-post-text h4 a,
				.site-footer .footer-widget .widget .recent-post-item .recent-post-text .rcomment'
			)
		),
		array(
			'id'        => 'widget_link_hover_color',
			'type'      => 'color',
			'title'     => esc_html__('Widget Link Hover Color', 'webtheme'),
			'default'  => '',
			'output'    => array(
				'color' => '.site-footer .footer-widget .widget ul li a:hover,
				.site-footer .footer-widget .widget .recent-post-item .recent-post-text h4 a:hover'
			)
		),
		array(
			'id'        => 'webtheme_widget_bg_color',
			'type'      => 'background',
			'title'     => esc_html__('Widget Section BG', 'webtheme'),
			'default'  => '',
			'output'    => array('.site-footer .footer-widget'),
			'default'  => array(
				'background-color' => '',
			)					
		),
		array(
			'id'             => 'webtheme_widget_section_spacing',
			'type'           => 'spacing',
			'output'         => array('.site-footer .footer-widget'),
			'mode'           => 'padding',
			'units'          => array('em', 'px'),
			'units_extended' => 'false',
			'title'          => esc_html__('Padding Option', 'webtheme'),
			'desc'           => esc_html__('You can enable or disable any piece of this field. Top, Right, Bottom, Left, or Units.', 'webtheme'),
			'default'            => array(
				'padding-top'     => '', 
				'padding-right'   => '', 
				'padding-bottom'  => '', 
				'padding-left'    => '',
				'units'          => 'px', 
			)
		),
	),
);

Redux::set_section( $opt_name, $section );

$section = array(
	'title'      => esc_html__( 'Copyright Area CSS', 'webtheme' ),
	'id'         => 'copyright_subsection',
	'subsection' => true,
	'icon'   => 'el el-share-alt',
	'fields'     => array(
		array(
			'id'        => 'footer_copyright_style',
			'type'      => 'select',
			'title'     => esc_html__('Copyright Style Layout', 'webtheme'),
			'customizer_only'   => false,
			'options'   => array(
				'copy_s1' => esc_html__('Centered copyright text','webtheme'),
				'copy_s2' => esc_html__('Left Text and Right Menu','webtheme'),
				
			),
		),
		array(
			'id'        => 'copyright-text',
			'type'      => 'editor',
			'title'     => esc_html__('Copyright information', 'webtheme'),
			'subtitle'  => esc_html__('HTML tags allowed: a, br, em, strong', 'webtheme'),
			'default'	=> esc_html__('Copyright &copy; webtheme all rights reserved.', 'webtheme'),
			'args'      => array(
				'teeny'            => true,
				'textarea_rows'    => 5,
				'media_buttons' => false,
			)
		),
		array(								
			'id'        => 'webtheme_copyright_text_color',
			'type'      => 'color',
			'title'     => esc_html__('Copyright Text Color', 'webtheme'),
			'default'  => '',
			'output'    => array(
				'color' => '.theme-main-footer .theme-copyright-area .copyright-text p, .theme-copyright-area .copyright-text ul li a'
			)
		),
		array(								
			'id'        => 'webtheme_copyright_icon_color',
			'type'      => 'color',
			'title'     => esc_html__('Copyright Icon Color', 'webtheme'),
			'default'  => '',
			'output'    => array(
				'color' => '.theme-copyright-area .copyright-text ul li a i'
			)
		),
		array(
			'id'        => 'webtheme_copyright_text_hover_color',
			'type'      => 'color',
			'title'     => esc_html__('Copyright Text Hover Color', 'webtheme'),
			'default'  => '',
			'output'    => array(
				'color' => '.theme-main-footer .theme-copyright-area .copyright-text p:hover, .theme-copyright-area .copyright-text ul li a:hover'
			)
		),
		array(
			'id'        => 'webtheme_copyright_bg_color',
			'type'      => 'background',
			'title'     => esc_html__('Copyright Section BG', 'webtheme'),
			'default'  => '',
			'output'    => array('
				.theme-copyright-area
			'),
			'default'  => array(
				'background-color' => '',
			)
		),
		array(
			'id'             => 'copyright_section_spacing',
			'type'           => 'spacing',
			'output'         => array('.theme-copyright-area'),
			'mode'           => 'padding',
			'units'          => array('em', 'px'),
			'units_extended' => 'false',
			'title'          => esc_html__('Padding Option', 'webtheme'),
			'desc'           => esc_html__('You can enable or disable any piece of this field. Top, Right, Bottom, Left, or Units.', 'webtheme'),
			'default'            => array(
				'padding-top'     => '', 
				'padding-right'   => '', 
				'padding-bottom'  => '', 
				'padding-left'    => '',
				'units'          => 'px', 
			)
		),
	),
);

Redux::set_section( $opt_name, $section );

<?php
/*  START Theme Typography. */
$section = array(
	'title'  => esc_html__( 'Theme Typography', 'webtheme' ),
	'id'     => 'typography',
	'icon'   => 'el el-asterisk',
	'fields' => array(
		array(
			'id'          => 'webtheme_body_typography',
			'type'        => 'typography', 
			'title'       => esc_html__('Body Typography', 'webtheme'),
			'line-height'   => true,
			'output'      => array('body'),
			'units'       =>'px',
			'default'     => array(
				'color'       => '', 
				'font-style'  => '', 
				'font-family' => '', 
				'font-size'   => '',						
			),
		),
		array(
			'id'       => 'body_background',
			'type'     => 'background',
			'title'    => __('Body Background', 'webtheme'),
			'default'	=> array(
				'background' => '',
			),
			'output'    => array('body'),
		),
				array(
					'id'          => 'webtheme_heading_typographyh1',
					'type'        => 'typography', 
					'title'       => esc_html__('Heading Typography H1', 'webtheme'),
					'line-height'   => false,
					'font-style'  => false, 					
					'output'      => array('
						h1				
					'),
					'units'       =>'px',
					'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'webtheme'),
					'default'     => array(
						'color'       => '', 
						'font-family' => '', 
						'font-size'   => '',						
					),
				),
				array(
					'id'          => 'webtheme_heading_typographyh2',
					'type'        => 'typography', 
					'title'       => esc_html__('Heading Typography H2', 'webtheme'),
					'line-height'   => false,
					'font-style'  => false, 					
					'output'      => array('
						h2				
					'),
					'units'       =>'px',
					'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'webtheme'),
					'default'     => array(
						'color'       => '', 
						'font-family' => '', 
						'font-size'   => '',						
					),
				),
				array(
					'id'          => 'webtheme_heading_typographyh3',
					'type'        => 'typography', 
					'title'       => esc_html__('Heading Typography H3', 'webtheme'),
					'line-height'   => false,
					'font-style'  => false, 					
					'output'      => array('
						h3			
					'),
					'units'       =>'px',
					'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'webtheme'),
					'default'     => array(
						'color'       => '', 
						'font-family' => '', 
						'font-size'   => '',						
					),
				),
				array(
					'id'          => 'webtheme_heading_typographyh4',
					'type'        => 'typography', 
					'title'       => esc_html__('Heading Typography H4', 'webtheme'),
					'line-height'   => false,
					'font-style'  => false, 					
					'output'      => array('
						h4				
					'),
					'units'       =>'px',
					'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'webtheme'),
					'default'     => array(
						'color'       => '', 
						'font-family' => '', 
						'google'      => true,
						'font-size'   => '',						
					),
				),
				array(
					'id'          => 'webtheme_heading_typographyh5',
					'type'        => 'typography', 
					'title'       => esc_html__('Heading Typography H5', 'webtheme'),
					'line-height'   => false,
					'font-style'  => false, 					
					'output'      => array('
						h5					
					'),
					'units'       =>'px',
					'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'webtheme'),
					'default'     => array(
						'color'       => '', 
						'font-family' => '', 
						'font-size'   => '',						
					),
				),
				array(
					'id'          => 'webtheme_heading_typographyh6',
					'type'        => 'typography', 
					'title'       => esc_html__('Heading Typography H6', 'webtheme'),
					'line-height'   => false,
					'font-style'  => false, 					
					'output'      => array('
						h6					
					'),
					'units'       =>'px',
					'subtitle'    => esc_html__('Typography option with each property can be called individually.', 'webtheme'),
					'default'     => array(
						'color'       => '', 
						'font-family' => '', 
						'font-size'   => '',			
					),
				),
	),
);

Redux::set_section( $opt_name, $section );
/* <- END Theme Typography. */
<?php
$section = array(
	/* -> START Breadcrumb Area. */
	'title'  => esc_html__( 'Bredcrumb Area', 'webtheme' ),
	'id'     => 'breadcrumb',
	'icon'   => 'el el-asterisk',
	'fields' => array(
		array(
			'id'       => 'breadcrumb-background',
			'type'     => 'background',
			'title'    => __('Breadcrumb Background', 'webtheme'),
			'output'    => array('.theme-breadcumb-section'),
		),

		array(
			'id'          => 'breadcrumb-title-typography',
			'type'        => 'typography', 
			'title'       => __('Title Typography', 'webtheme'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.theme-breadcumb-section .theme-text-content h2'),
			'units'       =>'px',
			'subtitle'    => __('Typography option with each property can be called individually.', 'webtheme'),
			'default'     => array(
				'color'       => '', 
				'font-style'  => '', 
				'font-family' => '', 
				'google'      => true,
				'font-size'   => '', 
				'line-height' => ''
			),
		),

		array(
			'id'        => 'webtheme_bread_current_page_color',
			'type'      => 'color',
			'title'     => esc_html__('Breadcrumb Current Text Color', 'webtheme'),
			'default'  => '',
			'output'    => array(
				'color' => '.theme-breadcumb-section .theme-text-content ul li:nth-last-child(-n+1)'
			)
		),
		array(
			'id'             => 'breadcrumb_spacing',
			'type'           => 'spacing',
			'output'         => array('.theme-breadcumb-section'),
			'mode'           => 'padding',
			'units'          => array('em', 'px'),
			'units_extended' => 'false',
			'title'          => esc_html__('Padding Option', 'webtheme'),
			'desc'           => esc_html__('You can enable or disable any piece of this field. Top, Right, Bottom, Left, or Units.', 'webtheme'),
			'default'            => array(
				'padding-top'     => '',
				'padding-right'   => '',
				'padding-bottom'  => '',
				'padding-left'    => '',
				'units'          => 'px',
			)
		),
	),
);

Redux::set_section( $opt_name, $section );

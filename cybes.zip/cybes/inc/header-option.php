<?php
/**
 * Top Header area start here
 */
$section = array(
	'title' => __( 'Header', 'webtheme' ),
	'id'    => 'header',
	'desc'  => __( 'These are global settings for Header. You can change the setting for each page separately if you wish.', 'webtheme' ),
	'icon'  => 'el el-asterisk',
);

Redux::set_section( $opt_name, $section );

$section = array(
	'title'      => esc_html__( 'Header Top', 'webtheme' ),
	'id'         => 'header_top',
	'subsection' => true,
	'icon'   => 'el el-share-alt',
	'fields'     => array(
		array(
			'id'       => 'top_email',
			'type'     => 'text',
			'title'    => esc_html__( 'Email Address', 'webtheme' ),
			'desc'     => esc_html__( 'Enter email address', 'webtheme' ),
			'default'     => esc_html__( 'info@example.com', 'webtheme' ),
		),
		array(
			'id'       => 'top_location',
			'type'     => 'text',
			'title'    => esc_html__( 'Company Location', 'webtheme' ),
			'desc'     => esc_html__( 'Enter Your address', 'webtheme' ),
			'default'     => esc_html__( 'New Road London.', 'webtheme' ),
		),
		array(
			'id'       => 'top_phone',
			'type'     => 'text',
			'title'    => esc_html__( 'Phone Number', 'webtheme' ),
			'desc'     => esc_html__( 'Enter phone number', 'webtheme' ),
			'default'     => esc_html__( '+880 123 456 789', 'webtheme' ),
		),
		array(
            'id'       => 'top_social_icons',
            'type'     => 'sortable',
            'title'    => esc_html__('Enter Social Icons', 'webtheme'),
            'subtitle' => esc_html__('Enter social links', 'webtheme'),
            'mode'     => 'text',
			'label'    => true,
            'options'  => array(
                'flaticon-facebook-4'     => '',
                'flaticon-instagram-logo'    => '',
                'flaticon-pinterest-1'     => '',
                'flaticon-linkedin-2'     => '',
                'flaticon-vimeo'   => '',
                'flaticon-skype'      => '',
                'flaticon-email'      => '',
            ),
			'default' => array(
				'flaticon-facebook-4'     => esc_url('#'),
				'flaticon-instagram-logo'	=> esc_url('#'),
				'flaticon-pinterest-1'     => esc_url('#'),
				'flaticon-linkedin-2'     => esc_url('#'),
				'flaticon-vimeo'   => '',
				'flaticon-skype'      => '',
				'flaticon-email'      => '',
				
				
			),
		),
		array(
			'id'          => 'top-left-color',
			'type'        => 'color', 
			'title'       => __('Top Menu Text Color', 'webtheme'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.theme-top-menu, .theme-main-header .theme-top-menu .theme-text-content .top-menu-left span,
			  .theme-main-header .theme-top-menu .theme-text-content .top-menu-left a'),
			'units'       =>'px',
			'subtitle'    => __('Top Menu text color enter here', 'webtheme'),
		),
		array(
			'id'          => 'top-left-text-icon',
			'type'        => 'color', 
			'title'       => __('Top Menu Text Icon Color', 'webtheme'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.theme-main-header .theme-top-menu .theme-text-content .top-menu-left i'),
			'units'       =>'px',
			'subtitle'    => __('Top Menu text icon color enter here.', 'webtheme'),
		),
		array(
			'id'          => 'top-icon-color',
			'type'        => 'color', 
			'title'       => __('Top Menu icon color', 'webtheme'),
			'google'      => true, 
			'font-backup' => true,
			'output'      => array('.theme-main-header .theme-top-menu .theme-text-content .top-menu-right ul li a i'),
			'units'       =>'px',
			'subtitle'    => __('Top Menu icol color enter here', 'webtheme'),
		),
	    array(         
	        'id'       => 'top-background',
	        'type'     => 'background',
	        'title'    => __('Top Bar Background', 'webtheme'),
	        'subtitle' => __('Top Bar background with image, color, etc.', 'webtheme'),
	        'output'    => array('.theme-main-header .theme-top-menu '),
	    ),
	),
);

Redux::set_section( $opt_name, $section );
	/* End Top Header Area
    *   Header area start here.
	*/
$section = array(
	'title'      => esc_html__( 'Header Logo', 'webtheme' ),
	'id'         => 'header_logo',
	'subsection' => true,
	'icon'   => 'el el-share-alt',
	'fields'     => array(
		array(
			'id'       => 'default_logo',
			'type'     => 'media',
			'title'    => esc_html__( 'Main Menu Logo', 'webtheme' ),
			'desc'     => esc_html__( 'Upload a Main Menu Default logo.', 'webtheme' ),
		),
		array(
			'id'       => 'transparent_logo',
			'type'     => 'media',
			'title'    => esc_html__( 'Transparent Menu Logo', 'webtheme' ),
			'desc'     => esc_html__( 'Upload a Main Menu Transparent logo.', 'webtheme' ),
		),
	),
);

Redux::set_section( $opt_name, $section );

$section = array(
	'title'      => esc_html__( 'Header Menu', 'webtheme' ),
	'id'         => 'webtheme_menu',
	'subsection' => true,
	'icon'   => 'el el-share-alt',
	'fields'     => array(
		array(
			'id'       => 'button_text',
			'type'     => 'text',
			'title'    => esc_html__( 'Button Text', 'webtheme' ),
			'placeholder'  => 'Enter Button Text',
			'default'  => 'Contact Us',
		),
		array(
			'id'       => 'button_link',
			'type'     => 'text',
			'title'    => esc_html__( 'Button Link', 'webtheme' ),
			'default'  => 'your site link here',
		),
		array(
			'id'        => 'menu_link_color',
			'type'      => 'color',
			'title'     => esc_html__('Link Color', 'webtheme'),
			'default'  => '',
			'output'    => array(
				'color' => '.theme-main-header .theme-main-menu .manu-wrapper .menu-ul li a',
			)
		),
		array(
			'id'        => 'menu_link_hover_color',
			'type'      => 'color',
			'title'     => esc_html__('Link Hover Color', 'webtheme'),
			'default'  => '',
			'output'    => array(
				'color' => '.theme-main-header .theme-main-menu .manu-wrapper .menu-ul li a:hover',
			)
		),
		array(
			'id'        => 'menu_button_color',
			'type'      => 'color',
			'title'     => esc_html__('Menu Button & Search Text Color', 'webtheme'),
			'default'  => '',
			'output'    => array(
				'color' => '.theme-main-header .header-button, .theme-main-header .main-menu .main-navigation .header-nav .search i'
			)
		),
		array(
			'id'        => 'menu_button_bg',
			'type'      => 'color',
			'title'     => esc_html__('Menu Button & Search BG Color', 'webtheme'),
			'default'  => '',
			'output'    => array(
				'background-color' => '.theme-main-header .header-button, .theme-main-header .main-menu .main-navigation .header-nav .search i',
			)
		),
		array(
			'id'        => 'webtheme_menu_bg_color',
			'type'      => 'background',
			'title'     => esc_html__('Main Menu BG Color', 'webtheme'),
			'default'  => '',
			'output'    => array('
				.theme-main-header
			'),
			'default'  => array(
				'background-color' => '',
			)
		),
		array(
			'id'        => 'submenu_bg_color',
			'type'      => 'background',
			'title'     => esc_html__('Sub Menu BG Color', 'webtheme'),
			'default'  => '',
			'output'    => array('
				.theme-main-header .theme-main-menu .manu-wrapper .menu-ul li .sub-menu
			'),
			'default'  => array(
				'background-color' => '',
			)					
		),
		array(
			'id'             => 'menu_spacing',
			'type'           => 'spacing',
			'output'         => array('.theme-main-header .main-menu'),
			'mode'           => 'padding',
			'units'          => array('em', 'px'),
			'units_extended' => 'false',
			'title'          => esc_html__('Section Padding Option', 'webtheme'),
			'desc'           => esc_html__('You can enable or disable any piece of this field. Top, Right, Bottom, Left, or Units.', 'webtheme'),
			'default'            => array(
				'padding-top'     => '', 
				'padding-right'   => '', 
				'padding-bottom'  => '', 
				'padding-left'    => '',
				'units'          => 'px', 
			)
		),

	),
);

Redux::set_section( $opt_name, $section );
/*  End Header Area.*/
<?php
/*
 * Template part for displaying posts
 */
?>
<div class="single-blog-post-content blog-details-blog">
    <div class="row">
		<div class="col-lg-4 col-md-4">
            <?php get_sidebar();?>
        </div>
        <div class="col-lg-8 col-md-8">
        	<div class="blog-post-img">
        		<?php the_post_thumbnail('webtheme-blog-default'); ?>
        	</div>
        	<div class="blog-post-text-content blog-details-blog-content">
        		<div class="blog-post-category">
        			<?php the_category();?>
        		</div>
        		<div class="blog-post-title">
        			<h1><?php echo wp_trim_words(get_the_title(), 30,''); ?></h1>
        		</div>
        		<!-- <div class="blog-author-admin">
        			<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"><?php the_author(); ?></a>
        		</div> -->
        		<!-- <div class="blog-post-time">
        			<span><?php echo get_the_time(get_option('date_format')); ?></span>
        		</div> -->
        		<div class="blog-post-description">
        			<?php
        			the_content();
        			wp_link_pages(
        				array(
        					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'webtheme' ),
        					'after'  => '</div>',
        				)
        			);
        			?>
        		</div>
        	</div>
	    </div>
	    </div>
	
</div>

<?php
/*
 * Template part for displaying posts
 */
?>
<div class="blog-content-category-section">
	<div class="blog-post-image">
		<?php the_post_thumbnail('webtheme-blog-default'); ?>
	</div>
	<div class="blog-content">
		<div class="blog-list-content">
			<?php if ( 'post' === get_post_type() ) : ?>
				<div class="blog-content-author-info">
					<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"><?php the_author(); ?></a>
					<span><?php echo get_the_time(get_option('date_format')); ?></span>
					<span class="blog-content-comment"><a href="<?php comments_link(); ?>">
						<?php comments_number( esc_html__('0 Comments','webtheme'), esc_html__('1 Comments','webtheme'), esc_html__('% Comments','webtheme') );?>
							</a>
					</span>
				</div>
				<?php endif; ?>
			</div>
		<div class="blog-content-title ">
			<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		</div>
		<div class="blog-post-description">
			<p><?php echo wp_trim_words(get_the_content(), 20, ' '); ?></p>
			<?php
			/*the_excerpt();*/
			?>
		</div>
		<div class="blog-button blog-content-button">
			<a href="<?php the_permalink(); ?>"><?php esc_html_e('Read More', 'webtheme'); ?> </a>
		</div>
	</div>
</div>
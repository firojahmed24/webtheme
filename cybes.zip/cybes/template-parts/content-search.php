<?php
/**
 * Template part for search
 * @link https://codex.wordpress.org/Template_Hierarchy
 * @package webtheme
 */
?>
<div class="blog-search-section">
	<div class="blog-post-img">
		<?php the_post_thumbnail('webtheme-blog-default'); ?>
	</div>
	<div class="blog-post-text-content blog-details-blog-content">
		<div class="blog-post-category">
			<?php the_category();?>
		</div>
		<div class="blog-post-title">
			<h1><?php echo wp_trim_words(get_the_title(), 30,''); ?></h1>
		</div>
		<div class="blog-author-admin">
			<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"><?php the_author(); ?></a>
		</div>
		<div class="blog-post-time">
			<span><?php echo get_the_time(get_option('date_format')); ?></span>
		</div>
	</div>
</div>
<?php
/*
 * Template part for displaying page content in page.php
 */
?>
	<header class="blog-header">
		<?php the_title( '<h1 class="blog-title">', '</h1>' ); ?>
	</header>
	<?php webtheme_post_thumbnail(); ?>

	<div class="blog-content">
		<?php
		the_content();

		wp_link_pages(
			array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'webtheme' ),
				'after'  => '</div>',
			)
		);
		?>
	</div>

	<?php if ( get_edit_post_link() ) : ?>
		<footer class="blog-footer">
			<?php
			edit_post_link(
				sprintf(
					wp_kses(
						/* translators: %s: Name of current post. Only visible to screen readers */
						__( 'Edit <span class="screen-reader-text">%s</span>', 'webtheme' ),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					wp_kses_post( get_the_title() )
				),
				'<span class="edit-link">',
				'</span>'
			);
			?>
		</footer><!-- .blog-footer -->
	<?php endif; ?>
<?php
/*
 * Template Name: Blog Grid 2 Column
 */
get_header();
?>
	<!--  Breadcrumb section start here  -->
	<div class="theme-breadcumb-section">
		<div class="container">
			<div class="theme-text-content">
				<h2><?php the_title(); ?></h2>
				<?php webtheme_breadcrumbs(); ?>
			</div>
		</div>
	</div>
	<!--  Breadcrumb section end here  -->	
	<!--  Blog Grid 2column start here -->
	<div class="blog-grid-section blog-grid-2column">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12">
					<div class="row">
						<?php
						$page = ( get_query_var( 'page' ) ? get_query_var( 'page' ) : 1 );
						$paged = ( get_query_var( 'paged' ) ? get_query_var( 'paged' ) : $page );
						$wp_query = new WP_Query( array(
							'post_type' => 'post',
							'paged'     => $paged,
							'page'      => $paged,
						) );
						while ( have_posts() ) : the_post(); ?>
							<div class="col-md-6">
									<div class="single-blog-grid blog-grid-2column">
									<div class="blog-grid-thumbnail">
										<?php webtheme_post_thumbnail(); ?>
										<div class="blog-grid-category">
											<?php the_category();?>
										</div>
									</div>
									<div class="blog-grid-content">
										<div class="blog-grid-author-info">
											<?php if ( 'post' === get_post_type() ) : ?>
											<div class="blog-grid-date">
												<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"><?php the_author(); ?></a>
												<span><?php echo get_the_time(get_option('date_format')); ?></span>
											</div>
											<?php endif; ?>
										</div>
										<div class="blog-grid-title ">
											<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
										</div>
										<div class="blog-grid-description">
											<p><?php echo wp_trim_words(get_the_content(), 10, ' '); ?></p>
										</div>
										<div class="blog-grid-button">
											<a href="<?php the_permalink(); ?>"><?php esc_html_e('Learn More', 'webtheme'); ?> </a>
										</div>
									</div>
								</div>
							</div>
						<?php endwhile; ?>
					</div>
				</div>
			</div>
		</div>
	</div>	
<?php 
get_footer();
<?php
/**
 * Template Name: webtheme Full Width
 * @since webtheme 1.0.0
 */
get_header();		
?>
<div class="container-fluid">
	<?php
	get_template_part( 'includes/header' , 'page-title' ); ?>						
	<?php while ( have_posts() ) : the_post(); ?>
			<?php the_content(); ?>
	<?php endwhile; ?>	
</div>
<?php 
get_footer();
<?php
/**
 * Template Name: WebTheme Template
 * @since webtheme 1.0.0
 * @package WordPress
 * @since Zackas 1.0
 */
get_header();
?>
	<?php
	$show_breadcumb  = get_post_meta( get_the_ID(),'_webtheme_breadcrumbs', true );
	$breadcrumb_title  = get_post_meta( get_the_ID(),'_webtheme_breadcrumb_title', true );
	$bg_image  = get_post_meta( get_the_ID(),'_webtheme_bg_image', true );
	$page_text_transform  = get_post_meta( get_the_ID(),'_webtheme_page_text_transform', true );

	?>
	<?php if( $show_breadcumb == 0 ){ ?>
	<div class="theme-breadcumb-section" <?php if($bg_image){?> style="background-image:url(<?php echo esc_url($bg_image)?>)" <?php } ?>>
		<div class="container">
			<div class="theme-text-content">
				<?php if( $breadcrumb_title == 'show_title' ) { ?>
				<h2 <?php if($page_text_transform){?> style="text-transform:<?php echo $page_text_transform?>" <?php } ?> ><?php wp_title(''); ?></h2>
				<?php } ?>
				<?php webtheme_breadcrumbs(); ?>
			</div>
		</div>
	</div>
	<?php } ?>
	<div class="webtheme-template-page">
		<?php
		while ( have_posts() ) : the_post();
			the_content();
		endwhile;
		?>
	</div>
<?php
get_footer();
<?php
/**
 * Template Name: Blog List
 */
get_header();
get_template_part( 'includes/header' , 'page-title' ); ?>
<!--  Breadcrumb section start here  -->
	<div class="theme-breadcumb-section">
		<div class="container">
			<div class="theme-text-content">
				<h2><?php the_title(); ?></h2>
				<?php webtheme_breadcrumbs(); ?>
			</div>
		</div>
	</div>
<!--  Breadcrumb section end here  -->
	
	<!-- BLOG LIST AREA START HERE -->
	<div class="blog-list-area">
		<div class="container">				
			<div class="row">
				<?php
					$page = ( get_query_var( 'page' ) ? get_query_var( 'page' ) : 1 );
					$paged = ( get_query_var( 'paged' ) ? get_query_var( 'paged' ) : $page );
					$wp_query = new WP_Query( array(
						'post_type' => 'post',
						'paged'     => $paged,
						'page'      => $paged,
					) );
				if ( $wp_query->have_posts() ) : ?>				
					<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
						<div class="row">								
							<?php while ( $wp_query->have_posts() ) : $wp_query->the_post();
								global $post; ?>
								<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
									<div class="blog-list-thumbnail">
										<?php webtheme_post_thumbnail(); ?>
											<div class="blog-list-category">
												<?php the_category();?>
											</div>
										</div>
									<div class="single-blog-list">
										<div class="blog-list-content">
											<?php if ( 'post' === get_post_type() ) : ?>
												<div class="blog-list-author-info">
													<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"><?php the_author(); ?></a>
													<span><?php echo get_the_time(get_option('date_format')); ?></span>
													<span class="blog-list-comment"><a href="<?php comments_link(); ?>">
														<?php comments_number( esc_html__('0 Comments','webtheme'), esc_html__('1 Comments','webtheme'), esc_html__('% Comments','webtheme') );?>
														</a>
													</span>
												</div>
											<?php endif; ?>
										</div>
										<div class="blog-list-title ">
											<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
										</div>
										<div class="blog-list-description">
											<p><?php echo wp_trim_words(get_the_content(), 10, ' '); ?></p>
										</div>
										<div class="blog-list-button">
											<a href="<?php the_permalink(); ?>"><?php esc_html_e('Learn More', 'webtheme'); ?> </a>
										</div>
									</div>
								</div>
							<?php endwhile; // while has_post(); ?>								
						</div>
					</div>
					<div class="col-lg-4 col-md-4">
                        <?php get_sidebar();?>
                    </div>
				<?php endif; // if has_post() ?>
			</div>
		</div>
	</div>
	<!-- END BLOG AREA START -->
<?php 
get_footer();
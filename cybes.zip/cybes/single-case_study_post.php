<?php
/*
 *   Case Study details show here
 */
get_header(); 
get_template_part( 'includes/header' , 'page-title' ); ?>
	<!--  Breadcrumb section start here  -->
	<div class="theme-breadcumb-section">
		<div class="container">
			<div class="theme-text-content">
				<h2>Case Study Details</h2><!--<h2><?php the_title(); ?></h2> -->
				<?php webtheme_breadcrumbs(); ?>
			</div>
		</div>
	</div>
	<!--  Breadcrumb section end here  -->
	<!--  Case Study Details start here -->
	<div class="case-study-details">
		<div class="container">
			<div class="row">
				<div class="col-md-12  col-sm-12 col-xs-12">
					<div class="case-study-dtls-thumb">
						<?php the_post_thumbnail(); ?>											
					</div>
				</div>
				<div class="col-md-12  col-sm-12 col-xs-12">
					<div class="case-study-details-info">
						<?php the_content(); ?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="case-study-dtls-description">
						<div class="case-study-dtls-title">
							<h1><?php the_title(); ?></h1>
						</div>
						<div class="case-study-dtls-description">
							<?php  $description = get_post_meta( get_the_ID(),'webtheme_casestudy_description', true );  ?>
							<p><?php echo $description; ?></p>
						</div>
					</div>				
				</div>
			</div>
		</div>
	</div>
	<!--  Case Study Details end here -->		
<?php
get_footer();
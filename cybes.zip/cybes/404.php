<?php
/*
 * Displaying 404 pages (not found)
 */
get_header();
?>
<?php global $cybes_opt; ?>

	<div class="theme-breadcumb-section">
		<div class="container">
			<div class="theme-text-content">
				<h2>Page not found</h2>
				<?php webtheme_breadcrumbs(); ?>
			</div>
		</div>
	</div>
	<div class="error-section">
		<div class="container">
			<div class="erroe-content">
				<div class="error-main-title">
					<h3>404 / Error Page</h3>
				</div>
				<div class="error-title-content">
					<?php if( !empty($cybes_opt['error_information']) ){ ?>
						<h3><?php echo $cybes_opt['error_information']; ?></h3>
					<?php }else{ ?>
						<div class="error-oops-title">
							<h3>Oops! That page can’t be found.</h3>
						</div>
						<div class="error-please-title">
							<h2>Please try others key again.</h2>
						</div>
					<?php } ?>
				</div>

				<div class="error-page-description">
					<p><?php esc_html_e( 'You should try again with other keyword.', 'webtheme' ); ?></p>
				</div>
			</div>
		</div>
	</div>
<?php
get_footer();

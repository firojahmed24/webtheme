<?php
/**
 * webtheme functions
 ** @link https://developer.wordpress.org/themes/basics/theme-functions/
 * @package webtheme
 */
if ( ! defined( '_S_VERSION' ) ) {
	define( '_S_VERSION', '5.0.0' );
}
if ( ! function_exists( 'webtheme_setup' ) ) :

	function webtheme_setup() {
		
		load_theme_textdomain( 'webtheme', get_template_directory() . '/languages' );
		
		add_theme_support( 'woocommerce' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		add_theme_support( 'title-tag' );

		add_image_size( 'webtheme-recent-image', 80, 80, true );
		add_image_size( 'webtheme-single-portfolio', 1170, 600, true );
		add_image_size( 'webtheme-case-thumb', 400, 250, true );
		add_theme_support( 'post-thumbnails');

		register_nav_menus(
			array(
				'menu-1' => esc_html__( 'Header Menu', 'webtheme' ),
				'menu-2' => esc_html__( 'Copyright Menu', 'webtheme' ),
			)
		);
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);
		/* Set up the WordPress core custom background feature.*/
		add_theme_support(
			'custom-background',
			apply_filters(
				'webtheme_custom_background_args',
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				)
			)
		);
		/* Add theme support for selective refresh for widgets.*/
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 250,
				'width'       => 250,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'webtheme_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function webtheme_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'webtheme_content_width', 640 );
}
add_action( 'after_setup_theme', 'webtheme_content_width', 0 );

/**
 * Register widget area.
 */
function webtheme_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'webtheme' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'webtheme' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer 1', 'webtheme' ),
			'id'            => 'footer-1',
			'description'   => esc_html__( 'Add widgets here.', 'webtheme' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'   => '</h4>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer 2', 'webtheme' ),
			'id'            => 'footer-2',
			'description'   => esc_html__( 'Add widgets here.', 'webtheme' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'   => '</h4>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer 3', 'webtheme' ),
			'id'            => 'footer-3',
			'description'   => esc_html__( 'Add widgets here.', 'webtheme' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'   => '</h4>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer 4', 'webtheme' ),
			'id'            => 'footer-4',
			'description'   => esc_html__( 'Add widgets here.', 'webtheme' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="widget-title">',
			'after_title'   => '</h4>',
		)
	);
}
add_action( 'widgets_init', 'webtheme_widgets_init' );
/*  =========================================================
              All css link start here webtheme.
  ==========================================================*/
function webtheme_scripts() {
	/* Google Fonts link here */
    wp_enqueue_style( 'noto', 'https://fonts.googleapis.com/css2?family=Noto+Serif:ital,wght@0,100..900;1,100..900&display=swap', false,'1.1.1','all');
	wp_enqueue_style( 'mulish', 'https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap', false,'1.1.1','all');
	/*wp_enqueue_style( 'font_awesome_css', get_template_directory_uri() . '/assets/css/font-awesome.min.css', false,'4.7.0','all');    */
	wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css', false,'4.7.0','all');
	wp_enqueue_style( 'bootstrap_css', get_template_directory_uri() . '/assets/css/bootstrap.min.css', false,'4.6.2','all');
	wp_enqueue_style( 'customization', get_template_directory_uri() . '/assets/css/theme-customization.css', false,'1.1.0','all');
	wp_enqueue_style( 'header', get_template_directory_uri() . '/assets/css/header-main.css', false,'1.1.0','all');
	wp_enqueue_style( 'post-style', get_template_directory_uri() . '/assets/css/post-type-style.css', false,'1.1.0','all');
	wp_enqueue_style( 'theme-responsive', get_template_directory_uri() . '/assets/css/theme-responsive.css', false,'1.1.0','all');

	wp_enqueue_style( 'webtheme-style', get_stylesheet_uri(), array(), _S_VERSION );

     /*   All css link End
       All js link start here*/

	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'theme-script', get_template_directory_uri() . '/assets/js/theme-script.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'imageload_js', get_template_directory_uri() . '/assets/js/imagesloaded.pkgd.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'isotope', get_template_directory_uri() . '/assets/js/isotope.pkgd.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'animation_js', get_template_directory_uri() . '/assets/js/jquery.animatedheadline.min.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'webtheme-theme', get_template_directory_uri() . '/assets/js/theme-customize.js', array(), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'webtheme_scripts' );

/*  ====================================================
            End here webtheme All css link.
  ====================================================*/

/* Admin script   */
if(!function_exists('webtheme_admin_scripts')){
	
	function webtheme_admin_scripts() {
		wp_enqueue_media();
		wp_enqueue_script('webtheme-uploader', get_template_directory_uri() .'/js/webtheme_uploader.js', false, '', true );
	}
}
add_action('admin_enqueue_scripts', 'webtheme_admin_scripts');

/* Title word count   */
if(!function_exists('webtheme_title')){
	
	function webtheme_title($limit){
		$title = explode(' ' , get_the_title());
		$titles = array_slice($title , 0, $limit);
		echo implode(' ', $titles);
	}
}
/**
 * Header Menu
 */
function add_arrow( $output, $item, $depth, $args ){

	if('menu-1' == $args->theme_location && $depth >= 0 ){
		if (in_array("menu-item-has-children", $item->classes)) {
	        $output .='<span class="sub-menu-toggle"><i class="fa fa-angle-down" aria-hidden="true"></i></span>';
	    }
	}
    return $output;
}
add_filter( 'walker_nav_menu_start_el', 'add_arrow',10,4);

function fields_list() {
	return array(
		'mm-megamenu' => 'Activate MegaMenu',
	);
}

/* Setup fields   */
function megamenu_fields( $id, $item, $depth, $args ) {
	$fields = fields_list();
	foreach ( $fields as $_key => $label ) :
		$key   = sprintf( 'menu-item-%s', $_key );
		$id    = sprintf( 'edit-%s-%s', $key, $item->ID );
		$name  = sprintf( '%s[%s]', $key, $item->ID );
		$value = get_post_meta( $item->ID, $key, true );
		$class = sprintf( 'field-%s', $_key );
		?>
		<p class="description description-wide <?php echo esc_attr( $class ) ?>">
			<label for="<?php echo esc_attr( $id ); ?>"><input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="1" <?php echo ( $value == 1 ) ? 'checked="checked"' : ''; ?> /><?php echo esc_attr( $label ); ?></label>
		</p>
		<?php
	endforeach;
}
add_action( 'wp_nav_menu_item_custom_fields', 'megamenu_fields', 10, 4 );
/* Create Columns   */
function megamenu_columns( $columns ) {
	$fields = fields_list();
	$columns = array_merge( $columns, $fields );
	return $columns;
}
add_filter( 'manage_nav-menus_columns', 'megamenu_columns', 99 );
/* Save fields  */
function megamenu_save( $menu_id, $menu_item_db_id, $menu_item_args ) {
	if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
		return;
	}
	check_admin_referer( 'update-nav_menu', 'update-nav-menu-nonce' );
	$fields = fields_list();

	foreach ( $fields as $_key => $label ) {
		$key = sprintf( 'menu-item-%s', $_key );

		/* Sanitize. */
		if ( ! empty( $_POST[ $key ][ $menu_item_db_id ] ) ) {
			/* Do some checks here... */
			$value = $_POST[ $key ][ $menu_item_db_id ];
		} else {
			$value = null;
		}

		/* Update.*/
		if ( ! is_null( $value ) ) {
			update_post_meta( $menu_item_db_id, $key, $value );
		} else {
			delete_post_meta( $menu_item_db_id, $key );
		}
	}
}

add_action( 'wp_update_nav_menu_item', 'megamenu_save', 10, 3 );
/*
	All php Link start here 

 Custom Header*/
require get_template_directory() . '/inc/custom-header.php';

/*   Custom template tags for this theme.*/
require get_template_directory() . '/inc/template-tags.php';

/* Functions hooking into WordPress.*/
require get_template_directory() . '/inc/template-functions.php';

 /* Customizer additions.*/
require get_template_directory() . '/inc/customizer.php';

/*  Global function (comment) */
require get_template_directory(). '/inc/global-function.php';

/*   Breadcrumb area theme option */
require get_template_directory(). '/inc/theme-breadcrumb.php';

/*	Metabox	*/
require get_template_directory(). '/inc/metaboxes.php';

/*	TGM Loader  */
require get_template_directory(). '/inc/TGM-Plugin-Activation-2.6.1/tgm-class-loader.php';

/*   Walker */
require get_template_directory(). '/inc/walker.php';

/*	Load Jetpack compatibility file. */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}
/*  Load Redux option framework.  */
if ( class_exists('ReduxFrameworkPlugin') ) {
	require get_template_directory(). '/inc/theme-option.php';
}
/* 
	All pages Link end here 
 */
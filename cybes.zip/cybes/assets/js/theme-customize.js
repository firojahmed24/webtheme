(function ($) {
	'use strict';
	// PORTFOLIO Post Type js
	$('.portfolio_section_tab').imagesLoaded(function () {
		if ($.fn.isotope) {
			var $portfolio = $('.portfolio_section_tab');
			$portfolio.isotope({
				itemSelector: '.grid-item',
				filter: '*',
				resizesContainer: true,
				layoutMode: 'masonry',
				transitionDuration: '0.8s'
			});
			$('.portfolio_category_menu li').on('click', function () {
				$('.portfolio_category_menu li').removeClass('active_category_menu');
				$(this).addClass('active_category_menu');
				var selector = $(this).attr('data-filter');
				$portfolio.isotope({
					filter: selector,
				});
			});
		};
	});
	
	/*----------------------------------------
           go-to-top
    ----------------------------------------*/
        $(document).on('click', '.go-to-top', function () {
            $("html,body").animate({
                scrollTop: 0
            }, 500);
        });

    $(window).on("scroll", function() {
        /*---------------------------------------
            back-to-top
        -----------------------------------------*/
        var ScrollTop = $('.go-to-top');
        if ($(window).scrollTop() > 400) {
            ScrollTop.fadeIn(400);
        } else {
            ScrollTop.fadeOut(400);
        }

    });

        /*---------------------------------------
            video box js start
        -----------------------------------------*/
	document.addEventListener("DOMContentLoaded", function () {
		const videoButton = document.querySelector(".video-popup-button");
		const videoPopup = document.createElement("div");
		
		videoPopup.classList.add("video-popup-overlay");
		videoPopup.innerHTML = `
			<div class="video-popup-content">
				<span class="video-popup-close">&times;</span>
				<iframe src="" allowfullscreen></iframe>
			</div>
		`;
		
		document.body.appendChild(videoPopup);
	
		if (videoButton) {
			videoButton.addEventListener("click", function (event) {
				event.preventDefault();
				const videoURL = this.getAttribute("href").replace("watch?v=", "embed/");
				videoPopup.querySelector("iframe").src = videoURL;
				videoPopup.style.display = "flex";
			});
		}
	
		videoPopup.querySelector(".video-popup-close").addEventListener("click", function () {
			videoPopup.style.display = "none";
			videoPopup.querySelector("iframe").src = "";
		});
	
		videoPopup.addEventListener("click", function (event) {
			if (event.target === this) {
				videoPopup.style.display = "none";
				videoPopup.querySelector("iframe").src = "";
			}
		});
	});
	


})(jQuery);


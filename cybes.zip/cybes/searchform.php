<?php 
/**
 * Searchform Template
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package webtheme
 */
 ?>

<form action="<?php echo esc_url(home_url('/'))?>" class="webtheme search-form">
    <div>
        <input type="text" name="s" class="form-control" placeholder="<?php echo esc_attr__('Search','webtheme');?>">
    </div>
    <button class="search-submit-btn" type="submit"><i class="fa fa-search"></i></button>
</form>
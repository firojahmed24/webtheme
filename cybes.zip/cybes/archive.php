<?php
/**
 * The template for displaying archive pages
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 * @package webtheme
 */
get_header();
?>
	<div class="theme-breadcumb-section">
		<div class="container">
			<div class="archive-section-category-breadcumb">
				<h1>Category :</h1>
            	<h2><?php single_cat_title();?> </h2>
				<?php webtheme_breadcrumbs(); ?>
			</div>
		</div>
	</div>
	<div class="archive-section">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div>
						<?php if ( have_posts() ) : ?>
							<?php
							while ( have_posts() ) :
								the_post();
								get_template_part( 'template-parts/content', 'list' );
							endwhile;
							the_posts_navigation();
						else :
							get_template_part( 'template-parts/content', 'none' );
						endif;
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php
get_footer();
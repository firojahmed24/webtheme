<?php
/**
 * portfolio details show here
 * @package webtheme
 */
	get_header();
?>
	<!--  Breadcrumb section start here  -->
	<div class="theme-breadcumb-section">
		<div class="container">
			<div class="theme-text-content">
				<h2>Portfolio Details</h2><!--<h2><?php the_title(); ?></h2> -->
				<?php webtheme_breadcrumbs(); ?>
			</div>
		</div>
	</div>
	<!--  Breadcrumb section end here  -->
	<!--  Portfolio Details start here -->
	<div class="portfolio-details">
		<div class="container">
			<div class="row">
				<div class="col-md-12  col-sm-12 col-xs-12">
				<div class="portfolio-dtls-title">
					<!--<h2>Project Details View</h2>-->
					<h1><?php the_title(); ?></h1>
				</div>
				<div class="portfolio-dtls-thumb">
					<?php the_post_thumbnail(); ?>											
				</div>
				</div>
				<div class="col-md-12  col-sm-12 col-xs-12">
					<div class="portfolio-details-info">
						<div class="portfolio-details-information">
							<?php the_content(); ?>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="portfolio-dtls-content">
						<div class="portfolio-dtls-content-title">
							<h1>About this Project</h1>
						</div>
						<div class="portfolio-dtls-description">
							<?php  $description = get_post_meta( get_the_ID(),'webtheme_portfolio_description', true );  ?>
							<p><?php echo $description; ?></p>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="portfolio-dtls-project-content">
						<div class="portfolio-dtls-project-content-title">
							<h1>View Some Related Projects</h1>
						</div>
						
					</div>
				</div>
			</div>
		<!--  Extra Portfolio start here -->
			<div class="portfolio-details-portfolio">
				<div class="portfolio-section option1">
					<?php $the_query = new \WP_Query( array(
						'post_type' => 'portfolio_post_type',
						'posts_per_page' => 6,
						'order' =>'DSC',
						) ); 
					?>
					<div class="portfolio-category-tab-menu">
						<ul id="filter" class="portfolio_category_menu ">
							<li class="active_category_menu" data-filter="*">All Work</li>
								<?php
									$categories = get_terms('portfolio_post_type_category');
									foreach ( $categories as $single_category ) {
								?>
							<li data-filter=".<?php echo esc_attr( $single_category->slug );?>"><?php echo esc_html( $single_category->name );?></li>
							<?php } ?>
						</ul>
					</div>
					<div class="portfolio_section_tab">
						<div class="row">
							<?php while ($the_query->have_posts()) : $the_query->the_post();
								$terms = get_the_terms(get_the_ID(), 'portfolio_post_type_category');
							?>
							<div class="col-md-4 col-lg-<?php echo $settings['select_column']; ?> grid-item <?php foreach( $terms as $single_slug){echo $single_slug->slug. ' ';} ?>">
								<div class="single-portfolio">
									<div class="portfolio-thumb">
									<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail();?></a>
									</div>
									<div class="portfolio-text-content">
										
											<div class="portfolio-category">
												<a href="<?php the_permalink(); ?>">
													<?php if( $terms ){
														foreach( $terms as $single_slugs ){?>
														<?php echo $single_slugs->name ;?>											
													<?php }}?>
												</a>
											</div>
											<div class="portfolio-title">
												<h1><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h1>
											</div>
										</div> 
									</div>
								</div>
							<?php endwhile; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php
get_footer();
<?php
/**
 *  webtheme footer.
 * @package webtheme
 */
?>
<?php global $cybes_opt; ?>
	<footer class="theme-main-footer">
		<?php if( !empty($cybes_opt['footer_widget_toggle']) && $cybes_opt['footer_widget_toggle']==true ){ ?>
		<?php $footer_column_count = $cybes_opt['widget_column_count']; ?>
		<?php if( 0 != $footer_column_count ) { ?>
		<div class="footer-widget">
			<div class="container">
				<div class="row">

				<?php if( '' == $footer_column_count ){$footer_column_count = 4;}
				$footer_sidebar_class = floor( 12/$footer_column_count ); ?>

				<?php for( $footer = 1; $footer <= $footer_column_count; $footer++ ) { ?>

					<?php if ( is_active_sidebar( 'footer-' . $footer ) ) { ?>

					<div class="col-lg-<?php echo esc_attr( $footer_sidebar_class ); ?>">
						<?php dynamic_sidebar( 'footer-'. $footer ); ?>
					</div>

					<?php } ?>

				<?php } ?>

				</div>
			</div>
		</div>
		<?php } ?>
		<?php } ?>	
		<div class="theme-copyright-area">
			<div class="container">
				<div class="copyright-wrapper">
					<?php if(!empty($cybes_opt['footer_copyright_style']) && $cybes_opt['footer_copyright_style']=="copy_s2"){ ?>
					<div class="row align-items-center">
						<div class="col-md-6">
							<div class="copyright-text">
								<p><?php echo $cybes_opt['copyright-text']; ?></p>
							</div>
						</div>
						<div class="col-md-6">
							<div class="copyright-menu">
							<?php
							wp_nav_menu(
								array(
									'theme_location' => 'menu-2',
									'menu_id'        => 'copyright-menu',
									'fallback_cb' => false,
								)
							);
							?>
							</div>
						</div>
					</div>
					<?php }elseif(!empty($cybes_opt['footer_copyright_style']) && $cybes_opt['footer_copyright_style']=="copy_s1"){ ?>
						<div class="copyright-text" style="text-align: center;">
							<p><?php echo $cybes_opt['copyright-text']; ?></p>
						</div>
					<?php }else{?>
						<div class="copyright-text" style="text-align: center;">
							<p><?php echo $cybes_opt['copyright-text']; ?></p>
						</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</footer>
</div><!-- #page -->
<?php wp_footer(); ?>
</body>
</html>
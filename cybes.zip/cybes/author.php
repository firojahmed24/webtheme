<?php get_header(); ?>
<!--  Breadcrumb section start here  -->
<div class="theme-breadcumb-section">
        <div class="container">
            <div class="theme-text-content">
                <h2>Posts by : <?php the_author();?></h2>
                <h2><?php the_title(); ?></h2>
                <?php webtheme_breadcrumbs(); ?>
            </div>
        </div>
    </div>
<!--  Breadcrumb section end here  -->
<div class="blog-author-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <?php get_template_part( 'template-parts/content', '' ); ?> 
            </div>
        </div>
    </div>
</div>
<?php get_footer();?>